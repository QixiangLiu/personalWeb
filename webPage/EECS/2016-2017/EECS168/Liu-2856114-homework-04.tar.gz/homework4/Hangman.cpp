//
//  Hangman.cpp
//  eecs168_homework4

#include "Hangman.h"
#include <string>
#include <iostream>
using namespace std;
//constructor
//precondition: the disguised word size is set to the size of secret word,the size of missed Markers is set to Max Miss count
//postcondition:initial value of disguised word is ???????, , and the initial value of missed marker is OOOOOOO,guesscount is zero, and missesCount is zero;
Hangman::Hangman(string sec):secretWord(sec),MAX_MISSES_ALLOWED(7){
    disguisedWordSize = secretWord.length();

    disguisedWord = new char[disguisedWordSize];
    for(int i=0;i<disguisedWordSize;i++){
        if(secretWord.at(i)!=' '){
           disguisedWord[i]='?';
        }
    }
    missedMarkers = new char[MAX_MISSES_ALLOWED];
    for(int i =0;i<MAX_MISSES_ALLOWED;i++){
        missedMarkers[i]='O';
    }
    guessCount =0;
    missesCount =0;

}
//deconstructor
//precondition: delete heap
Hangman::~Hangman(){
    delete[] disguisedWord;
    delete[] missedMarkers;
}


//precondition: return the number of guess
int Hangman::getGuessCount(){
    return guessCount++;
}
//precondition: return the number of mistakes
int Hangman::getmissesCount(){
    return missesCount;
}
//precondition: convert char point array to string
//pstcondition: use string constructor
string Hangman::getMissedMaker(){
    string n(missedMarkers);
    return (n);
}
//precondition: distinguish guess character whether it is same as real words
//postcondition: if find same character from secret word, return true,otherwise it is false.
bool Hangman::guessCharacter(char c){
    bool flag = false;
    for(int i=0;i<disguisedWordSize;i++){
        if(c == secretWord.at(i)){
            disguisedWord[i] = c;
            flag = true;
        }
    }
    if(flag == false){
        int c =0;
        while(missedMarkers[c]=='X'){
            c++;
        }
        missedMarkers[c]='X';
    }
    return flag;
}


//precondition: find all of correct characters
//postcondition: if no ? in secret word, it is found.
bool Hangman::isFound(){
    for(int i=0;i<disguisedWordSize;i++){
        if(disguisedWord[i]=='?'){
            return false;
        }
    }
    return true;

}
//precondition: game over
//postcondition: make too much mistakes or find the correct secret word.
bool Hangman::isGameOver(){
    if(missedMarkers[MAX_MISSES_ALLOWED-1]=='X'||(isFound() == true)){
        return true;
    }else{
        return false;
    }
}
//precondition: convert character array pointer to string in Disguised word.
//postcondition: use string constructor.
string Hangman::getDisguisedWord(){
    string n(disguisedWord);
        return(n);

}

