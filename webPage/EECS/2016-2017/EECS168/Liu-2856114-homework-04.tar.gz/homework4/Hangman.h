//
//  Hangman.h
//  eecs168_homework4


#ifndef Hangman_h
#define Hangman_h

#include <string>
using namespace std;
class Hangman{
private:
    const string secretWord;
    char* disguisedWord;
    int disguisedWordSize;
    int guessCount;
    int missesCount;
    const int MAX_MISSES_ALLOWED;
    char* missedMarkers;
public:
    Hangman(string sec);
    ~Hangman();
    bool guessCharacter(char c);
    bool isGameOver();
    bool isFound();
    string getDisguisedWord();
    int getGuessCount();
    int getmissesCount();
    string getMissedMaker();
    



};


#endif /* Hangman_hpp */
