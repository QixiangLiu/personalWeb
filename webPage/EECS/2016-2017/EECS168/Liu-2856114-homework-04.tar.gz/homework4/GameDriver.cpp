//
//  GameDriver.cpp
//  eecs168_homework4
// QixiangLiu


#include "GameDriver.h"
#include <iostream>
using namespace std;

GameDriver::GameDriver(){
}

GameDriver::~GameDriver(){
}

void GameDriver::run(string word){
    string new_secret = word;
    char guess = '1';
    char exit ='y';
    while(exit=='y'||exit=='Y'){
    h1 = new Hangman(new_secret);
   
    cout << "Welcome to the Hangman Game!\n";
    cout <<"-----------------------------\n";
    do{
    cout << "Guess this: "<<h1->getDisguisedWord()<<endl;
    cout << "Guess so far: "<<h1->getGuessCount()<<endl;
    cout << "Misses: "<<h1->getMissedMaker()<<endl;
    cout << "Enter your guess character: ";
    cin >> guess;
    if(h1->guessCharacter(guess) == true){
        cout<<guess<< " is in the secret word!\n";
    }else{
        cout <<guess<<" is not in the secret word. Death draws closer.\n";
    }
    
    }while((h1->isGameOver()==false));
        if(h1->isFound()==true){
            cout <<"Game Over!\n";
            cout <<"Congratulations! You guess the secret word: "<< h1->getDisguisedWord()<<" in "<<h1->getGuessCount()<<" guesses!\n";
        }else{
            cout <<"You died, guess as if yout life depended on it. \n";
        }
    cout <<"Do you wan to play again? (y/n)\n";
    cin >> exit;
        if(exit =='y'||exit=='Y'){
            cout <<"Input a new secret word: ";
            cin >> new_secret;
            for(int i=0;i<100;i++)
                cout <<endl;
        }else{
            cout <<"GoodBye!\n";
        }

    }
    
    
}
