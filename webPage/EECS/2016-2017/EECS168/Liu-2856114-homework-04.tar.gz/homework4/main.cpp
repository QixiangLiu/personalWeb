/*
File: main.cpp
Author: Qixiang Liu
 KUID:2856114
 Homework: EECS168_homework4
 Description:  play hangman game that guess a secret word from user!
 Date: 04/26/17
 */
#include <iostream>
#include "GameDriver.h"
using namespace std;
int main(int argc, char* argv[]) {
    if(argc >=2){
        string secret="";
        int c = argc;
        for(int i=1;i<c;i++){
            secret +=argv[i];
           /*
            if(i!=c-1){
                secret +=" ";
            }
            */
        }
        GameDriver myDriver;
        myDriver.run(secret);
    }else{
        std::cout << "ERROR: Invalid number of arguments. Minimum of two required.\n";
    }
    return 0;
}
