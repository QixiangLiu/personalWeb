//
//  GameDriver.h
//  eecs168_homework4
//


#ifndef GameDriver_h
#define GameDriver_h

#include "Hangman.h"
#include <string>
class GameDriver{
public:
    void run(std::string word);
    GameDriver();
    ~GameDriver();
private:
    Hangman* h1;


};
#endif /* GameDriver_hpp */
