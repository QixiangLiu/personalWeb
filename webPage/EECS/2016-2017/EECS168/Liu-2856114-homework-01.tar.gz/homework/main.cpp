/*
File Name: TacoStand
Author: Qixiang Liu
KUID: 2856114
Email Address: q709l816@ku.edu
Homework Assignment Number: Homework1
Description: Make a menu to costomr they can oder anyfood anynumber,and anytimes!
Last Changed: 02/13/17
*/
#include <iostream>
#include <string>
#include <stdio.h>

const double OUT_OF_STATE_SHIPPING = 35.50;


using namespace std;

int main(){
    char choice1 = 'a', choice2 = 'a';
    double subtotal1=0.0, subtotal2 =0.0,subtotal3=0.0,subtotal4=0.0,subtotal5=0.0,subtotal6=0.0,subtotal7=0.0, subtotal8=0.0
    ,tax =0.0, total =0.0;
    int number = 0;
    int count1=0,count2=0,count3=0,count4=0,count5=0,count6=0,count7=0;//total of number of food
    char next ='y';
    char order ='y';
    double discount1 =0.0,discount2 =0.0,discount3 =0.0;
    
    string city="";
    string state="";
    string streetAddress="";
    int ZipCode =0;
    
    
    cout << "Welcome to the taco stand! \n" <<endl;

    while((order =='y')||(order=='Y')){
    while((next == 'y') || (next=='Y')){        // More ORDER Y/y
        cout << "Place order: \n" << "============ \n";
        cout << "(c/C) Chicken Taco $3.50 \n";
        cout << "(n/N) Nachos $6.50 \n";
        cout << "(s/S) Salad $5.00 \n";
        cout << "(w/W) Water $1.00 \n";
        cout << "Choice: ";
        cin >> choice1;
        cout << endl;
    
        //if choose chicken or nachos, must have topping
    if((choice1 =='c') || (choice1 == 'C') ||(choice1 =='n')||(choice1 =='N')){
        cout << "Toppings (given on the side):\n" << "============ \n";
        cout << "(t/T) Tomatoes $0.75 \n";
        cout << "(c/C) Cheese $1.5 \n";
        cout << "(h/H) Hot Sause $0.3 \n";
        cout << "(n/N) None $0.0 \n";
        cout << "Choice: ";
        cin >> choice2;
        cout << endl;
    }else{
        choice2 ='a';
    }
        
        // How many?
        cout << "Quantity: \n" << "============ \n";
        cout << "How many?: ";
        cin >> number;

        
        
        
        // the main food calculate
        if((choice1 =='c') || (choice1 == 'C')){    //chicken
            count1 = count1 + number;
            subtotal1 = 3.50 * count1;
        }else if((choice1 == 's') || (choice1 == 'S')){ //saled
            count2 = count2 +number;
            subtotal2 = 5.00 * count2;
        }else if((choice1 == 'w'|| (choice1 == 'W'))){//water
            count3 =count3+number;
            subtotal3 = 1.00 * count3;
        }else if ((choice1 == 'n'|| (choice1 == 'N'))){//nachos
            count4= count4 +number;
            subtotal4 = 6.50 * count4;
        
        }
        
        //Topping calcuate
        if((choice2 =='t')||(choice2 =='T')){//tomatoes
            count5 = count5 + number;
            subtotal5 = 0.75 * count5;
            
        }else if((choice2 =='c'||(choice2 == 'C'))){    //cheese
            count6 = count6 + number;
            subtotal6 = 1.5 * count6;

            
        }else if ((choice2 =='h'||(choice2 =='H'))){    //hot sause
            count7 = count7 + number;
            subtotal7 =0.3 * count7;

            
        }else if((choice2 =='n'||(choice2 =='N'))){
            subtotal8 = 0.0;
        }
        
        
        cout << "Do you want to order more (y/Y)?: "; // order again
        cin >> next;
        
    }
    
    
    
    
    
    //Receipt
    cout << "Receipt: \n" << "============ \n";
    cout << "Sub total\n";
    if(count1 >0){ //chicken
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(1);
        cout << "\t" << count1 << " Chicken Taco @ $3.50: " <<subtotal1<<endl;
        
    }
    if(count2 >0){ //salad
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(2);
        cout << "\t" << count2 << " Saled @ $5.0: " <<subtotal2<<endl;
       
    }
    if(count3 >0){      //water
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(2);
        cout << "\t" << count3 << " Water @ $1.0: " <<subtotal3<<endl;
        
    }
    if(count4 >0){//nachos
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(2);
        cout << "\t" << count4 << " Nachos @ $6.5: " <<subtotal4<<endl;
    }
    if(count5 >0){ //tomatoes
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(2);
        cout << "\t" << count5 << " Tomatoes @ $0.75: " <<subtotal5<<endl;
    }
    if(count6>0){//cheese
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(2);
        cout << "\t" << count6 << " Cheese @ $1.5: " <<subtotal6<<endl;
    }
    if(count7>0){//hot sause
        std::cout.setf(std::ios::fixed);
        std::cout.setf(std::ios::showpoint);
        std::cout.precision(2);
        cout << "\t" << count7 << " Hot Sause @ $0.3: " <<subtotal7<<endl;
    }
    
    
    
    

    //tax
    cout << "Tax \n";
    tax = (subtotal1 + subtotal2+subtotal3+subtotal4+subtotal5+subtotal6+subtotal7+subtotal8) * 0.08;
    std::cout.setf(std::ios::fixed);
    std::cout.setf(std::ios::showpoint);
    std::cout.precision(2);
    cout << "\t 8% of $" <<(subtotal1 + subtotal2+subtotal3+subtotal4+subtotal5+subtotal6+subtotal7+subtotal8) << ": " << tax << endl;
    //total except for discount
    total = tax + subtotal1 + subtotal2+subtotal3+subtotal4+subtotal5+subtotal6+subtotal7+subtotal8;

    //discount
    cout << "Discount \n";
    if(count1 >=2){
        discount1 = 1.00;
        total = total-discount1;
        cout << "$1.00 off with 2 or more tacas: -$" << discount1<<endl;
    }
     if(count2>=50){
        discount2 = 0.5 * subtotal2;
        total = total-discount2;
        cout << "50% off with 50 or more Salads: -$" << discount2<<endl;

    }
    if(count3>=5){
        discount3 = 1.00;
        total = total-discount3;
        cout << "$1.00 off with 5 or more waters: -$" << discount3<<endl;
    }

    //total
    cout << "Total \n";
    
   cout << "\t $" << total << endl;
        cout <<endl;
   
    //Delivery
    
    cout << "Delivery Information:\n"<< "============\n";
    cout << "City: ";
    cin >>city;
    cout << "State: ";
        cin >>state;
        //2 character of state
        while(state.length()!=2){
            cout <<"Please write abbreviation of state(Limite two character).";
            cin >>state;
        }
    
   //address
    cout << "Address: ";
        cin.ignore(1, '\n');
    getline(cin,streetAddress);
    //zipcode
        cout << "Zip Code: ";
    cin >> ZipCode;
        //basic 5 numbers of zipcode
        while(((ZipCode/10000) ==0) || ((ZipCode/10000)>9)){
            cout << "Please enter a correct zipcode: ";
            cin >> ZipCode;
        }
    cout <<endl;
    
    cout << "Your order will be delivered to " <<streetAddress<<", "<< city<<" "<<state<<", "<< ZipCode
        << "!\n";
        
        if(state=="ks"||(state=="KS")){
            cout << "Total \n";
            cout << "\t $" << total << endl;

        }else{
            cout << "Total(You are out of kansas) \n";
            cout << "\t $" << (total+OUT_OF_STATE_SHIPPING) << endl;
        }

	//reset data
	next = 'y';
	count1=0,count2=0,count3=0,count4=0,count5=0,count6=0,count7=0;
	subtotal1=0.0,subtotal2=0.0,subtotal3=0.0,subtotal4=0.0,subtotal5=0.0,subtotal6=0.0,subtotal7=0.0,subtotal8=0.0,tax=0.0, total =0.0;
	discount1 =0.0,discount2 =0.0,discount3 =0.0;
    cout << "Would you like to make another order (y/Y)?: ";
    cin >>order;
    
    }
    
    return 0;
}
