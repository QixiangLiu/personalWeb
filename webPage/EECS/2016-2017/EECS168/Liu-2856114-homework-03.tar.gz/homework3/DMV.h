//
//  DMV.hpp
//  eecs168_homework3
//


#ifndef DMV_h
#define DMV_h

#include "DriverLicenseRecord.h"

class DMV{
private:
    DriverLicenseRecord** arr;
    int arrSize;
public:
    DMV(string file);
    void menu();
    void run();
    ~DMV();

};

#endif /* DMV_hpp */
