//
//  DMV.cpp
//  eecs168_homework3


#include "DMV.h"
#include "DriverLicenseRecord.h"
#include <iostream>
#include <fstream>
#include <string>
#include <limits>
using namespace std;
void DMV:: menu(){
    cout <<"Select an option:\n";
    cout <<"1) Print all Driver Info \n";
    cout <<"2) Print all voters Info\n";
    cout <<"3) Print specific driver \n";
    cout <<"4) Create registered voter file \n";
    cout <<"5) Quit\n";
    cout <<"Enter your choice: ";
}
DMV::DMV(string file){
    string first;
    string last;
    int age;
    char voter;
    int license;
    int size =0;
    ifstream inFile;
    inFile.open(file);
    inFile >> size;
    arrSize =size;
    arr = new DriverLicenseRecord*[size];
    for(int i=0;i<size;i++){
        inFile >> first;
        inFile >> last;
        inFile >> age;
        inFile >> voter;
        inFile >> license;
        arr[i] = new DriverLicenseRecord(first,last,age,voter,license);
    }
}
DMV::~DMV(){
for(int i =0;i<arrSize;i++){
	delete arr[i];
}
	delete[] arr;
}
void DMV::run(){
    int choice =0;
    string store ="";
    int exit =0;
    
    while(exit !=5){
    menu();
    cin >> choice;
    while(cin.fail()||choice <=0||choice >5){    
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout <<"Sorry,your input did not seem to be an int or extend range. Try again: ";
    cin >> choice;
    }
    if(choice == 1){
        for(int i=0;i<arrSize;i++){
            cout << arr[i]->getLast()<<", "<<arr[i]->getFirst()<<" ("<<arr[i]->getAge()<<"): "<<arr[i]->getLicense()<<endl;
            
        }
       
    }else if(choice ==2){
        for(int i=0;i<arrSize;i++){
            if(arr[i]->getVoter()=='Y'){
                store += arr[i]->getLast()+ ", "+ arr[i]->getFirst() +" ("+ to_string(arr[i]->getAge())+"): "+ to_string(arr[i]->getLicense())+"\n";
            }
        }
        cout << store;
       
    }else if(choice ==3){
        int n =0;
        cout <<"Enter a specific driver license: ";
        cin >> n;
        bool flag2 = true;
        for(int i=0;i<arrSize;i++){
            if(n==arr[i]->getLicense()){
                cout << arr[i]->getLast()<<", "<<arr[i]->getFirst()<<" ("<<arr[i]->getAge()<<"): "<<arr[i]->getLicense()<<endl;
                flag2 = false;
            }
        }
        if(flag2 == true){
            cout <<"No people for the driver license: "<<n<<endl;
        }
        
        
        
    }else if(choice ==4){
        string name ="";
        cout <<"Enter file name: ";
        cin >> name;
        ofstream outFile;
        outFile.open(name);
        outFile << store;
       
    }else if(choice ==5){
        exit = 5;
    }
    }


}
