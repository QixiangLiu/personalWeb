//
//  DriverLicenseRecord.hpp
//  eecs168_homework3
//

#ifndef DriverLicenseRecord_h
#define DriverLicenseRecord_h
#include <string>
using namespace std;
class DriverLicenseRecord{
private:
    string last;
    string first;
    int age;
    char voter;
    int license;
public:
    DriverLicenseRecord(string f,string la,int a,char v,int l);
    int getAge();
    char getVoter();
    int getLicense();
    string getLast();
    string getFirst();
    void setAge(int a);
    void setVoter(char v);
    void setLicense(int l);
    void setLast(string la);
    void setFirst(string f);
    

};

#endif /* DriverLicenseRecord_hpp */
