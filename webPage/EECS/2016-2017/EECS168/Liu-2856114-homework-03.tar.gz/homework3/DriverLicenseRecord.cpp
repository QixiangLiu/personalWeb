//
//  DriverLicenseRecord.cpp
//  eecs168_homework3
//

#include "DriverLicenseRecord.h"
DriverLicenseRecord::DriverLicenseRecord(string f,string la,int a,char v,int l){
    last = la;
    first = f;
    age = a;
    voter = v;
    license = l;
}

int DriverLicenseRecord::getAge(){
    return age;
}
char DriverLicenseRecord::getVoter(){
    return voter;
}
int DriverLicenseRecord::getLicense(){
    return license;
}
string DriverLicenseRecord::getLast(){
    return last;
}
string DriverLicenseRecord::getFirst(){
    return first;
}
void DriverLicenseRecord::setAge(int a){
    age = a;
}
void DriverLicenseRecord::setVoter(char v){
    voter =v;
}
void DriverLicenseRecord::setLicense(int l){
    license = l;
}
void DriverLicenseRecord::setLast(string la){
    last = la;
}
void DriverLicenseRecord::setFirst(string f){
    first = f;
}
