/*
File Name: main.cpp
Author: Qixiang Liu
Assignment: EECS168_homework3
Description: read 55 people of driver license from the file.
Date: 04/14/17
*/

#include <iostream>
#include "DMV.h"

int main(int argc, char * argv[]) {
    string fileName = argv[1];
    DMV mydmv(fileName);
    mydmv.run();
    return 0;
}
