/*-------------------------------------------------
 * File Name: main.cpp
 * Author: Qixiang Liu
 * KUID: 2856114
 * Email Address: q709l816@ku.edu
 * Homework Assignment Number: 2
 * Description: Make some patterns to print or save to file.
 * Last changed: 03/02/17
 *
 ---------------------------------------------------*/

#include <iostream>
#include <string>
#include <fstream>

using namespace std;
string checkerboard(int n);
string twinIslands(int n);
string runTotal(int n);
string uppLeftTri(int n);
string uppRightTri(int n);
void menu();
int intCheck(int n);
void write(string filename,int size,int choice);
string choiceSwitch(int choice,int size, string pattern);
void FileOrPrint(int choice2,string file, int choice,int size,string pattern);

//void charCheck(char n);

int main(){
    string file ="",pattern ="";
    int size =0, choice =0;
    char choice2 ='a',exit ='y';
    do{
    menu();
    cin >>choice;
    choice = intCheck(choice);
    
    cout << "What is size do you want to disply: ";
    cin >> size;
    size = intCheck(size);
    cout << "(F)ile or (P)rint: ";
    cin >>choice2;
        while(choice2 !='f' && choice2 != 'F' && choice2 != 'p' && choice2 != 'P'){
            cout << "Incorrect! (F)ile or (P)rint: ";
            cin >> choice2;
        }
    
    FileOrPrint(choice2, file, choice, size, pattern);
    
   /*
    //Make a File
    if(choice2 =='f' || choice2 == 'F'){
        cout <<"Enter a file name to save pattern to: ";
        cin >> file;
        
        cout <<"Pattern saved to "<<file<<endl;
        write(file,size,choice);
        
    
    }else if(choice2 == 'p' || choice2 =='P'){  //print patterns
        pattern =choiceSwitch(choice,size,pattern);
        cout << pattern;
  
    }
*/
        
        cout << "Do you want to play again!(Y/N) ";
        cin >> exit;
        
        //reset data
        file ="";
        pattern ="";
        size =0;
        choice =0;
        choice2 ='a';
    }while(exit == 'y'||exit =='Y');
    return 0;
}

    
    
    
//checkerboard
string checkerboard(int n){
    string pattern ="";
    
    for(int i =0;i<n;i++){
        for (int j =0;j<n;j++){
            if((i+j)%2 == 0 ){
                pattern += "O";
                
            }else{
                pattern += "X";
            }
        }
        pattern += "\n";
    }
    
    return pattern;
 }
//twinIslands
string twinIslands(int n){
    string pattern ="";
    for(int i =0;i<n;i++){
        for (int j =0;j<n;j++){
            
            if(n%2 ==1){
                if((i<(n/2))&&(j<(n/2))){
                    pattern += "!";
                }else if((i>(n/2))&& (j>(n/2))){
                    pattern += "?";
            
                }else if((i+j)== (n-1)){
                    pattern +="*";
                }else{
                    pattern +="~";
                }
            }else{
                if((i<(n/2))&&(j<(n/2))){
                    pattern +="!";
                }else if((i>=(n/2))&& (j>=(n/2))){
                    pattern+="?";
                    
                }else if((i+j)== (n-1)){
                    pattern +="*";
                }else{
                    pattern +="~";
                }
            }
        }
        pattern += "\n";
    }

    return pattern;
}
//running total
string runTotal(int n){
    string pattern ="";
    for(int i =1;i<=(n*n);i++){
        pattern += to_string(i);
        if(i>0 && (i%n!=0)){
            pattern +=",";
        }
        if((i % n) == 0){
            pattern+= "\n";
        }
    }
    return pattern;
}
// upper left triangle
string uppLeftTri(int n){
    string pattern ="";
    for(int i =0;i<n;i++){
        for (int j =0;j<n;j++){
            if(i<=j){
                pattern+="*";
            }
        }
        pattern+= "\n";
    }
    return pattern;
}
//upper right triangle
string uppRightTri(int n){
    string pattern ="";
    for(int i =0;i<n;i++){
        for (int j =0;j<n;j++){
            if(j<i){
                pattern +=" ";
            }else{
                pattern +="*";
            }
        }
        pattern += "\n";
    }
    return pattern;
}

//patterns or menu

void menu(){
    cout <<"1) Checkerboard\n";
    cout <<"2) Twin Islands\n";
    cout <<"3) Running total\n";
    cout <<"4) Upper Left Triangle\n";
    cout <<"5) Upper Right Triangle \n";
    cout << "Choice: ";
}

//check input whether integer
int intCheck(int n){
    while ( cin.fail() )
    {
        cin.clear(); // unset failbit
        cin.ignore(); // skip bad input up to the next newline
        cout << "Error! Try again!";
        cin >> n;
    }
    
    cout << "You entered: " << n<<endl;
    return n;
}
/*
// check input whether char
void charCheck(char n){
    while ( cin.fail() )
    {
        cin.clear(); // unset failbit
        cin.ignore(); // skip bad input up to the next newline
        cout << "Error!";
        cin >> n;
    }
    
    cout << "You entered: " << n<<endl;
}
*/

//write to file
void write(string filename,int size,int choice){
    string pattern ="";
    ofstream myOutfile;
    
    myOutfile.open(filename);
    pattern = choiceSwitch(choice,size,pattern);
    myOutfile << pattern;
    
    
    myOutfile.close();
}

string choiceSwitch(int choice,int size, string pattern){
    switch(choice){
        case 1:
            pattern = checkerboard(size);
            break;
        case 2:
            pattern = twinIslands(size);
            break;
        case 3:
            pattern = runTotal(size);
            break;
        case 4:
            pattern = uppLeftTri(size);
            break;
        default:
            pattern = uppRightTri(size);
    }

    return pattern;
}

void FileOrPrint(int choice2,string file, int choice,int size,string pattern){
    //Make a File
    if(choice2 =='f' || choice2 == 'F'){
        cout <<"Enter a file name to save pattern to: ";
        cin >> file;
        
        cout <<"Pattern saved to "<<file<<endl;
        write(file,size,choice);
        
        
    }else if(choice2 == 'p' || choice2 =='P'){  //print patterns
        pattern =choiceSwitch(choice,size,pattern);
        cout << pattern;
        
    }
}

