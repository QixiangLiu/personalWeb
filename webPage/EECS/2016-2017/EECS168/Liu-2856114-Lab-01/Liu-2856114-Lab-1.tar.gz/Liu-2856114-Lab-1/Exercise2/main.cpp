#include<iostream>
int main(){

std::cout <<"My name is Qixiang Liu. \n" <<"I am an EECS major. \n" <<"My hobbies are:\n";
std::cout <<"\t Videos games \n" << "\t Movies \n" <<"\t Sleeping \n";
std::cout <<"Goodbye\n";


return 0;
	
}
