//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.
// This file is a subset of Carrano's file for Lab 8

// PARTIALLY COMPLETE.

/** @file BinaryTree.cpp */

#include "BinaryNodeTree.h"
#include "BinaryNode.h"
#include <iostream>

//////////////////////////////////////////////////////////////
//      Protected Utility Methods Section
//////////////////////////////////////////////////////////////
template <class ItemType>
BinaryNode<ItemType>* BinaryNodeTree<ItemType>::copyTree(
  const BinaryNode<ItemType>* treePtr)const
{
  BinaryNode<ItemType>* newTreePtr = nullptr;
  if(treePtr!=nullptr){
    newTreePtr = new BinaryNode<ItemType>(treePtr->getItem(),nullptr,nullptr);
    newTreePtr->setLeftChildPtr(copyTree(treePtr->getLeftChildPtr()));
    newTreePtr->setRightChildPtr(copyTree(treePtr->getRightChildPtr()));
  }
  return newTreePtr;
}

template <class ItemType>
void BinaryNodeTree<ItemType>::destroyTree(BinaryNode<ItemType> *subTreePtr){
  if(subTreePtr!=nullptr){
    destroyTree(subTreePtr->getLeftChildPtr());
    destroyTree(subTreePtr->getRightChildPtr());
    delete subTreePtr;
  }
}

template <class ItemType>
void BinaryNodeTree<ItemType>::inorder(void visit(ItemType&),BinaryNode<ItemType>* treePtr)const{
  if(treePtr!=nullptr){
    inorder(visit,treePtr->getLeftChildPtr());
    ItemType theItem = treePtr->getItem();
    visit(theItem);
    inorder(visit,treePtr->getRightChildPtr());
  }
}

template <class ItemType>
void BinaryNodeTree<ItemType>::preorder(void visit(ItemType&),BinaryNode<ItemType>* treePtr)const{
  if(treePtr!=nullptr){
    ItemType theItem = treePtr->getItem();
    visit(theItem);
    preorder(visit,treePtr->getLeftChildPtr());
    preorder(visit,treePtr->getRightChildPtr());
  }
}

template <class ItemType>
void BinaryNodeTree<ItemType>::postorder(void visit(ItemType&),BinaryNode<ItemType>* treePtr)const{
  if(treePtr!=nullptr){
    postorder(visit,treePtr->getLeftChildPtr());
    postorder(visit,treePtr->getRightChildPtr());
    ItemType theItem = treePtr->getItem();
    visit(theItem);
  }
}
//////////////////////////////////////////////////////////////
//      PUBLIC METHODS BEGIN HERE
//////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////
//      Constructor and Destructor Section
//////////////////////////////////////////////////////////////

template<class ItemType>
BinaryNodeTree<ItemType>::BinaryNodeTree(const ItemType& rootItem)
{
   rootPtr = new BinaryNode<ItemType>(rootItem, nullptr, nullptr);
}  // end constructor

template<class ItemType>
BinaryNodeTree<ItemType>::BinaryNodeTree(const ItemType& rootItem,
                                         const BinaryNodeTree<ItemType>* leftTreePtr,
                                         const BinaryNodeTree<ItemType>* rightTreePtr)
{
    rootPtr = new BinaryNode<ItemType>(rootItem, copyTree(leftTreePtr->rootPtr),
                                                 copyTree(rightTreePtr->rootPtr));
}  // end constructor

template<class ItemType>
BinaryNodeTree<ItemType>::BinaryNodeTree(const BinaryNodeTree<ItemType>& treePtr)
{
   rootPtr = copyTree(treePtr.rootPtr);
}  // end copy constructor

template<class ItemType>
BinaryNodeTree<ItemType>::~BinaryNodeTree()
{
   destroyTree(rootPtr);
}  // end destructor

//////////////////////////////////////////////////////////////
//      Public Traversals Section
//////////////////////////////////////////////////////////////

template<class ItemType>
void BinaryNodeTree<ItemType>::inorderTraverse(void visit(ItemType&)) const
{
   inorder(visit, rootPtr);
}  // end inorderTraverse

template <class ItemType>
void BinaryNodeTree<ItemType>::preorderTraverse(void visit(ItemType&)) const{
  preorder(visit,rootPtr);
}

template <class ItemType>
void BinaryNodeTree<ItemType>::postorderTraverse(void visit(ItemType&)) const{
  postorder(visit,rootPtr);
}

template<class ItemType>
bool BinaryNodeTree<ItemType>::isEmpty()const{return rootPtr==nullptr;}

template <class ItemType>
ItemType BinaryNodeTree<ItemType>::getRootData()const throw (PrecondViolatedExcep){
  if(isEmpty()){
    throw PrecondViolatedExcep("Binary Tree is Empty. \n");
  }else{
    return rootPtr->getItem();
  }
}

//overload operator=
template <class ItemType>
BinaryNodeTree<ItemType>& BinaryNodeTree<ItemType>::operator=(const BinaryNodeTree& rightHandSide){
if(this == &rightHandSide){
  return *this;
}else{
  BinaryNode<ItemType>* newRoot = rightHandSide.rootPtr;
    if(newRoot ==nullptr){
      this->rootPtr = nullptr;
    }else{
      this->rootPtr = copyTree(newRoot);
    }
    return *this;
}
}
