/*
file name: main.cpp
Author: Qixiang Liu
Homework: EECS268 lab08
Data: Oct 13th
Description: Binary Tree
*/

#include <iostream>
#include "Executive.h"
using namespace std;

int main(int argc, char** argv){
if(argc < 2){
	cout << "Wrong !\n";
}else{
  //string file = "input.txt";
  Executive myExe(argv[1]);
  myExe.run();
}
  
  return 0;
}
