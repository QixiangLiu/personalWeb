#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include "BinaryNodeTree.h"
#include "LinkedStack.h"
#include "PrecondViolatedExcep.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
class Executive{
public:
  Executive(string file);
  void run();
  bool isOperator(string str);
  static void print(string& str);
  void clientFunc(BinaryNodeTree<string>& bt);

private:
  LinkedStack<BinaryNodeTree<string>>* myStack;
  string filename;



};

#endif
