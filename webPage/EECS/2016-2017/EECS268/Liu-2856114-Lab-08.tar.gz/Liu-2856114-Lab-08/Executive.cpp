#include "Executive.h"

Executive::Executive(string file){
  filename = file;
  myStack = new LinkedStack<BinaryNodeTree<string>>;

}

void Executive::run(){
  ifstream inFile;
  inFile.open(filename);
  if(!inFile){
    cout << "it is wrong filename!\n";
    exit(0);
  }
  string str;
  bool flag = false;
  bool flag2 = true;
  while(!flag){
    inFile >> str;
    if(inFile.eof()){
      flag = true;
    }else{
      if(!isOperator(str)){
	try{
          BinaryNodeTree<string> b(str);
          myStack->push(b);
	}catch(PrecondViolatedExcep& e){
		flag2 =false;
		cout << e.what()<<endl;	
	}
      }else{
        try{
          BinaryNodeTree<string> Right =myStack->peek();
          myStack->pop();
          BinaryNodeTree<string> Left = myStack->peek();
          myStack->pop();
          BinaryNodeTree<string> b2(str,&Left,&Right);
          myStack->push(b2);
        }catch(PrecondViolatedExcep& e){
	  flag2 =false;
          cout << e.what()<<endl;
        }
      }
    }
  }
  inFile.close();
if(flag2 == true){
try{
  BinaryNodeTree<string> bt3 =myStack->peek();
  myStack->pop();
if(myStack->isEmpty()){
  clientFunc(bt3);
}else{
	cout << "No more operators OR excess operands\n";
}
}catch(PrecondViolatedExcep& e){
  cout << e.what()<<endl;
}
}
//delete stack
delete myStack;
myStack =nullptr;
}

bool Executive::isOperator(string str){
  return (str=="+"||str=="-"||str=="*"||str=="/");
}

void Executive::print(string& str){
  cout << str<<" ";
}

void Executive::clientFunc(BinaryNodeTree<string>& bt){
  cout << "PostOrder: \n";
  bt.postorderTraverse(print);
  cout <<endl <<"Inorder: \n";
  bt.inorderTraverse(print);
  cout << endl<<"PreOrder \n";
  bt.preorderTraverse(print);
  cout <<endl;
}
