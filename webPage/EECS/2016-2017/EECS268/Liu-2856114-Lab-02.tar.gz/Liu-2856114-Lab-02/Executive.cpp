//Executive.cpp

#include "Executive.h"


Executive::Executive(std::string file):count(0){
    int num =0;
    int size =0;
    ifstream inFile;
    inFile.open(file);
	if(!inFile){
		cout << "Input file Name is error!.\n";
		exit(0);
	}
    inFile >> count;
    myColl = new Collection<Roster>(count);
    while(true){
        if(inFile.eof()){
            break;
        }
        inFile >> nRos;
        inFile >> size;
        int *arr = new int[size];
        for(int i=0;i<size;i++){
            inFile >> num;
            arr[i] =num;
        }
        Roster myRos(nRos,size,arr);
        myColl->appendItem(myRos);
    }
    
    
    inFile.close();

    
}
void Executive::run(){
    int exit =0;
    int choice =0;
    do{
        menu();
        cin >> choice;
	while(cin.fail()){
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(),'\n');
		cout << "Sorry, your input did not seem to be int. Try again: ";
		cin >> choice;
	}
        if(choice ==1){
            int pos =0;
            cout << "Which number: ?\n";
	try{
            cin >>pos;
            myColl->getItem(pos).print();
            }catch(ItemNotFoundException &e){
		cout<<e.what()<<endl;	
	    }
        }else if(choice ==2){
            cout << myColl->getNumItem()<<endl;
            for(int i=0;i<myColl->getNumItem();i++){
                myColl->getItem(i).print();
            }
        }else if(choice ==3){
            exit =3;
        }else{
            cout << "Please enter a correct integer!\n";
        }
    }while(exit!=3);

}

void Executive::menu(){
    cout << "1) Print the roster for the num-th(begin 0th) class in the Collection array.\n"
    << "2) printAll\n"
    << "3) Quit \n"
    << "Choice: ";
}
