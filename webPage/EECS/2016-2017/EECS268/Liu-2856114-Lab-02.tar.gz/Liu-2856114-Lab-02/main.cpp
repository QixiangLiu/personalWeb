/*
 File name: main.cpp
 Author: Qixiang Liu
 KUID: 2856114
 Assignment: EECS268 Lab2
 Description:
 Date: 09/11/2017

 */

#include <iostream>
#include "Executive.h"
using namespace std;
int main(int argc, char* argv[]) {
    if(argc <2){
	cout <<"Incorrect Number.\n";
	}else{
    Executive myExc(argv[1]);
    myExc.run();
}
return (0);
      
}
