//Collection.h

#ifndef COLLECTION_H
#define COLLECTION_H
#include "ItemNotFoundException.h"

template <typename T>
class Collection{
public:
    Collection(int num); //constructor, argrument for size of array
    ~Collection();	//deconstructor of new items
    void appendItem(T item);	//appendItem to back of array
    T getItem(int which) const throw(ItemNotFoundException);	//attentiion to range.
    int getNumItem()const;		//getFunction to size of array
private:
    T* items;		//template of array
    int currSize; //number items actually currently stored in "items"
    int actSize; // the currently allocated size of the "items " array

};
#include "Collection.cpp"
#endif /* Collection_h */
