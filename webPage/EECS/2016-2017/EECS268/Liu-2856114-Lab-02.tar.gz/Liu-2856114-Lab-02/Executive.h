//Executive.h
#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include "Collection.h"
#include "Roster.h"
#include <iostream>
#include <fstream>
#include <limits>
#include <string>
using namespace std;


class Executive{
public:
    Executive(std::string file);
    void run();
private:
    int count;
    string nRos;
    Collection<Roster>* myColl;
    void menu();
    
};
#endif /* Executive_h */
