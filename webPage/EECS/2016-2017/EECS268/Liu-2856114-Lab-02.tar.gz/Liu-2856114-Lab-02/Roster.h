//Roster.h
#ifndef ROSTER_H
#define ROSTER_H

#include <iostream>
using namespace std;
class Roster{
public:
    Roster();	//default constrcutor
    //constructor of argument for classname, num of students, and array
    Roster(string cName,int nStudent,int* studentIDs);
    Roster(const Roster& old);	//copy constructor
    Roster& operator =(const Roster& arg); //operator overload.
    ~Roster();	//deconstructor
    void print()const;	// print all private variables
    
private:
    string className;
    int numStudents;
    int *studentID;


};
#endif /* Roster_h */
