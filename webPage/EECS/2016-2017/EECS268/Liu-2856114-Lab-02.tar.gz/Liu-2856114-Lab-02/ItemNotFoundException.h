
//ItemNotFoundExeception.h
#ifndef ITEMNOTFOUNDEXCEPTION_H
#define ITEMNOTFOUNDEXCEPTION_H
#include <stdexcept>
#include <iostream>
class ItemNotFoundException:public std::out_of_range {
public:
    ItemNotFoundException(const std::string& m =""):std::out_of_range(m.c_str()){}

};


#endif /* ItemNotFoundException_h */
