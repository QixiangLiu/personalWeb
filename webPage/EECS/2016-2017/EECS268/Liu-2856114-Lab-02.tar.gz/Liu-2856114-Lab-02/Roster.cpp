//Roster.cpp
#include "Roster.h"

Roster::Roster():className(" "),numStudents(0),studentID(nullptr){}

Roster::Roster(string cName,int nStudent,int *studentIDS):className(cName),numStudents(nStudent),studentID(studentIDS){
}

Roster::~Roster(){
	if(studentID!=nullptr){
		delete[] studentID;
	}
}


Roster::Roster(const Roster& old){
	className = old.className;
	numStudents =old.numStudents;
	studentID = new int[numStudents];		//new
	for(int i=0;i<numStudents;i++){
		studentID[i] = old.studentID[i];
	}
}

Roster& Roster::operator =(const Roster& arg){
	className = arg.className;
	numStudents = arg.numStudents;
	studentID = new int[numStudents];
	for(int i=0;i<numStudents;i++){
		studentID[i] = arg.studentID[i];
	}
/*
	int * temp = new int[numStudents];
	for(int i=0;i<numStudents;i++){
		temp[i] = arg.studentID[i];
	}
	studentID = new int[numStudents];
	for(int i=0;i<numStudents;i++){
		studentID[i] = temp[i];
	}
	delete[] temp;
*/
	return *this;
}

void Roster::print()const{
    cout << className <<" "<<numStudents <<" ";
    for(int i=0;i<numStudents;i++){
        cout << studentID[i]<<" ";
    }
    cout << "\n";
}
