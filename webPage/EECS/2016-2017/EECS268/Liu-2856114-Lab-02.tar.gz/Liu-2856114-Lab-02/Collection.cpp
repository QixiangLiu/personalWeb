//Collection.cpp
template <typename T>
Collection<T>::Collection(int num):currSize(0),actSize(num){
    items =  new T[actSize];
}
template <typename T>
Collection<T>::~Collection(){delete[] items;}

template <typename T>
void Collection<T>::appendItem(T item){
    if(currSize<actSize){
        items[currSize] = item;
    }else{
        int newSize = actSize*2;
        T* newItem = new T[newSize];
        for(int i=0;i<actSize;i++){
            newItem[i] = items[i];
        }
      
        delete[] items;
	items = nullptr;
        actSize = newSize;
        items = new T[actSize];
        for(int i=0;i<currSize;i++){
            items[i] = newItem[i];
        }
	items[currSize] = item;
	delete[] newItem;
	newItem = nullptr;
    }
    currSize++;
}

template <typename T>
T Collection<T>::getItem(int which)const throw(ItemNotFoundException){
    if(which>=0&&which<currSize){
        return items[which];
    }else{
        throw ItemNotFoundException("Error: out of range");
    }
}

template <typename T>
int Collection<T>::getNumItem()const{return currSize;}
