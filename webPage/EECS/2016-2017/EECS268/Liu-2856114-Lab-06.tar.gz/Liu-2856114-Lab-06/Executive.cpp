#include "Executive.h"

Executive::Executive(string file):filename(file){

}

Executive::~Executive(){}

void Executive::run(){
ifstream inFile;
inFile.open(filename);
while(!inFile){
cout << "incorrect input file name! Please try again:\n";
cin >> filename;
inFile.open(filename);
}

for(int i=0;i<9;i++){
	for(int j=0;j<9;j++){
		inFile >> Sudo[i][j];
	}
}

mySudo.setArray(Sudo);


int x = mySudo.solve(0,0);
if(x==-1){
cout << "There is not solution!\n";
}else{
mySudo.getArray();
}
inFile.close();

}
