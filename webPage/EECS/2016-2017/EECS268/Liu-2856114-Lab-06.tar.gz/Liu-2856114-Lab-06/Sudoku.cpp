#include "Sudoku.h"

Sudoku::Sudoku(){
}

Sudoku::~Sudoku(){}

void Sudoku::setArray(char newArr[9][9]){
  for(int i=0;i<9;i++){
    for(int j=0;j<9;j++){
      arr[i][j] = newArr[i][j];
    }
  }
}

void Sudoku::getArray()const{
  for(int i=0;i<9;i++){
    for(int j=0;j<9;j++){
      cout << arr[i][j]<<" ";
      if(j%3==2){
		cout << "  ";	
	}
    }
    cout << endl;
	if(i%3 ==2){
		cout << endl;	
	}
  }

}
//check Row
bool Sudoku::checkRow(int x, int y,char key){
  for(int i=0;i<9;i++){
    if(i!=y){
      if(arr[x][i]==key){
        return false;
      }
    }
  }
  return true;
}
//check Column
bool Sudoku::checkCol(int x, int y, char key){
  for(int i=0;i<9;i++){
    if(i!=y){
      if(arr[i][y]==key){
        return false;
      }
    }
  }
  return true;
}
//cheack 3*3
bool Sudoku::check3_3(int x, int y, char key){
  for(int i=x/3*3;i<x/3*3+3;i++){
    for(int j=y/3*3;j<y/3*3+3;j++){
      if(i!=x && j!=y){
        if(arr[i][j]==key){
          return false;
        }
      }
    }
  }
  return true;
}
bool Sudoku::checkAll(int x,int y, char key){
  bool success = true;
  success = checkRow(x,y,key);
  if(success ==true){
    success = checkCol(x,y,key);
    if(success == true){
      success = check3_3(x,y,key);
    }
  }
  return success;
}


int Sudoku::solve(int x, int y){
  if(x>8 || y>8){
    flag = true;
    return 1;
  }

  if(arr[x][y]!='_'){
    if(y<8&&y>=0){
      solve(x,y+1);
    }else{
        solve(x+1,0);
    }
  }else{
    for(int i=1;i<=9;i++){
      if(checkAll(x,y,'0'+i)==true){
        arr[x][y] = '0'+i;

        if(y<8&&y>=0){
          solve(x,y+1);
        }else{
          solve(x+1,0);
        }

        if(flag ==true){
          return 1;
        }
          arr[x][y] ='_'; //backtrack
      }
    }
  }
    return -1;
}
