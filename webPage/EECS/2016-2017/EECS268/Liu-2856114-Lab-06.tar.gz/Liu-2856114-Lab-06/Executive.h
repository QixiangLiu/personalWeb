#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include <iostream>
#include <fstream>
#include "Sudoku.h"
using namespace std;
class Executive{
public:
/*
constructor
read file name 
pre and post: none
arg: assign filename
*/
Executive(string file);
//deconstrutor
~Executive();
void run();
private:
string filename;
char Sudo[9][9];
Sudoku mySudo;	

};

#endif
