#ifndef SUDOKU_H
#define SUDOKU_H

#include <iostream>
using namespace std;

class Sudoku{
private:
char arr[9][9];
bool flag = false;
public:

  Sudoku();//default constructor
  ~Sudoku();//default deconstructor
/*
pre: x,y,key is from 1 to 9
post: none
return: check specific x of row
*/
  bool checkRow(int x, int y, char key);
/*
pre: x,y,key is from 1 to 9
post: none
return: check specific y of column
*/
  bool checkCol(int x, int y, char key);
/*
pre: x,y,key is from 1 to 9
post: none
return: check specific 3*3 sybsquares 
*/
  bool check3_3(int x, int y, char key);
//cheack rows, cols, 3*3 subsquares
  bool checkAll(int x, int y, char key);
/*
pre: x,y are from 1 to 9
post: none 
return: if -1 represent no solution,1 is represent have solution
*/
  int solve(int x,int y);
/*
pre: char type and 9*9 of array
post: none
return: set Sudoku in the begining
*/
  void setArray(char newArr[9][9]);
/*
pre: none
post: beautiful and readable
return: a 9*9 array
*/
  void getArray()const;
};



#endif
