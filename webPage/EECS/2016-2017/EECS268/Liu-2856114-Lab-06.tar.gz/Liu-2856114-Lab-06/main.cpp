/*
file name: name.cpp
Author: Qixiang Liu
Homework: EECS268_lab06
Due Data: Octorber 23
Description: recursion and backtracking-based to solve Sudoku puzzles
*/
#include <iostream>
#include "Executive.h"
using namespace std;

int main(int argc, char** argv){

if(argc <2){
	cout << "It is wrong!\n";
}else{
	Executive myExe(argv[1]);
	myExe.run();
}
/*
  Sudoku mySudo;
ifstream inFile;
inFile.open("input.txt");
char arr[9][9];
for(int i=0;i<9;i++){
  for(int j=0;j<9;j++){
    inFile >>arr[i][j];
  }
}
mySudo.setArray(arr);
mySudo.getArray();


cout << mySudo.solve(0,0)<<endl;
mySudo.getArray();



inFile.close();
*/
  return 0;
}
