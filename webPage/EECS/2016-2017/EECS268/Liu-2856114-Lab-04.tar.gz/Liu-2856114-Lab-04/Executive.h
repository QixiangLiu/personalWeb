#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include <iostream>
#include <fstream>
#include <string>
#include "List.h"
#include "Process.h"
#include "PrecondViolatedExcep.h"
using namespace std;

class Executive{
private:
  List<Process>* myList;
//  Process* myPro;
  string command;
  string processName;
  string function;
public:
  Executive(string file);
  /*
    pre: list can find processName;
    post:  if it is successful, the function will be returned, or process will be terminated.
    arg: None
    return: none
  */
  void returnFunction() throw(PrecondViolatedExcep);
  /*
    pre::list cam fomd processName
    post: if succeed, the process will call one function
    parm: none
    return: none
  */
  void callFunction() throw(PrecondViolatedExcep);
  /*
  pre: list is not empty when end of file;
  post: if it is successful, all list of process will be auto delete;
  param: none
  return none
  */
  void autoDelete();
};
#endif
