/*
File name: main.cpp
Author: Qixiang Liu
Homework: EECS268_lab4
KUID:2856114
Date: 10/02/14
Description: Stack and List
*/
#include <iostream>
#include "Executive.h"
#include "List.h"
#include "Stack.h"
using namespace std;
int main(int argc, char* argv[]){
  if(argc <2){
    cout << "Wrong command!\n";
  }else{
  Executive myExe(argv[1]);
 }
  return 0;
}
