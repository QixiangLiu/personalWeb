#include "Executive.h"

Executive::Executive(string file){
  ifstream inFile;
  inFile.open(file);
  if(!inFile){
    cout << "No input file name. \n";
    exit(0);
  }
  myList = new List<Process>;

  while(true){
    inFile >> command;
    if(inFile.eof()==true){
      autoDelete();
      break;
    }
    if(command == "start"){
      inFile >> processName;
      // create process put main function into it;
      //myPro = new Process(processName);
      Process myPro(processName);
      myList->insert(1,myPro);
      cout <<"Process "<<processName<<" has started.\n";
    }else{
      processName = command;
      inFile >> command;
      if(command =="calls"){
        inFile >>function;
        try{
          callFunction();
        }catch(PrecondViolatedExcep& rm){
          cout << rm.what()<<endl;
        }
      }else if(command =="returns"){
          try{
            returnFunction();
          }catch(PrecondViolatedExcep& rm){
            cout <<rm.what()<<endl;
          }
      }else{
        cout << "No right commands.\n";
      }
    }

}

inFile.close();
}

void Executive::returnFunction() throw(PrecondViolatedExcep){
  bool flag = false;
  for(int i=1;i<=myList->getLength();i++){
    if(myList->getEntry(i).getProcessName()==processName){
      flag =true;
      if(myList->getEntry(i).getFunction()=="main"){
        myList->getEntry(i).popMethod();
        myList->remove(i);
        cout <<processName <<" has terminated.\n";
      }else{
        cout <<"Process " <<processName<<" return from method "<< myList->getEntry(i).getFunction()<<endl;
        myList->getEntry(i).popMethod();
      }
      break;
    }
  }
  if(flag == false){
    throw PrecondViolatedExcep("Can not find correct target.");
  }
}

void Executive::callFunction() throw(PrecondViolatedExcep){
  bool flag =false;
  for(int i=1;i<=myList->getLength();i++){
      if(myList->getEntry(i).getProcessName()==processName){
        myList->getEntry(i).pushMethod(function);
        flag = true;
        break;
      }
  }
  if(flag ==false){
    throw PrecondViolatedExcep("No target to found.");
  }else{
    cout << "Process "<<processName<<" called method "<<function<<"."<<endl;
  }
}

void Executive::autoDelete(){
  if(!myList->isEmpty()){
    for(int i=1;i<=myList->getLength();i++){
      cout << "Process "<< myList->getEntry(i).getProcessName() << " are still active!.\n";
      cout << "start auto delete process\n";
      while(!myList->getEntry(i).emptyStack()){
        myList->getEntry(i).popMethod();
      }
      cout << "Finish auto delete.\n";
    }
  }
}
