#include "Process.h"
Process::Process(){

}

Process::Process(std::string proName):name(proName),method(nullptr){
  method = new Stack<std::string>;
  method->push("main");
}

std::string Process::getProcessName()const{return name;}

void Process::pushMethod(std::string func){
  method->push(func);  //insert to top
}

std::string Process::getFunction()const{
  try{
    return method->peek();
  }catch(PrecondViolatedExcep& rm){
    std::cout << rm.what()<<endl;
  }
}

void Process::popMethod(){
  try{
    return method->pop();
  }catch(PrecondViolatedExcep& rm){
    std::cout << rm.what()<<endl;
  }
}

bool Process::emptyStack(){
  return method->isEmpty();
}
