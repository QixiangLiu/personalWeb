#ifndef NODE_H
#define NODE_H
template <class T>
class Node{
private:
	T item;
	Node* next;
public:
	Node(){}
	Node(T anItem):item(anItem),next(nullptr){}
	Node(T anItem, Node* nextNode):item(anItem),next(nextNode){}
	T getItem()const{return item;}
	Node* getNext() const {return next;}
	void setItem(T newItem){item = newItem;}
	void setNext(Node* nextNode){next =nextNode;}
};
#endif
