template <class T>
List<T>::List():headPtr(nullptr),itemCount(0){}
template <class T>
List<T>::~List(){clear();}
template <class T>
List<T>::List(const List<T>& aList){
	itemCount = aList->itemCount;
	Node<T>* origin = aList->headPtr;
	if(origin ==nullptr){
		headPtr = nullptr;
	}else{
		//copy first Node
		headPtr = new Node<T>();
		headPtr->setItem(origin->getItem());
		//last-node pointer  copy remaing nodes
		Node<T>* newChainPtr = headPtr;
		while(origin !=nullptr){
			Node<T>* newChainPtr = origin->getNext();
			T nextItem = origin->getItem();
			Node<T>* newNode = new Node<T>(nextItem);
			newChainPtr->setNext(newNode);
			newChainPtr = newChainPtr->getNext();
		}
		newChainPtr->setNext(nullptr);
	}
}
template <class T>
bool List<T>::isEmpty()const{return itemCount==0;}

template <class T>
int List<T>::getLength()const{return itemCount;}

template <class T>
void List<T>::insert(int newPosition,const T& newEntry)throw(PrecondViolatedExcep){
	bool ableToInsert = (newPosition>=1)&&(newPosition <=itemCount+1);
	if(ableToInsert){
		Node<T>* newNode = new Node<T>(newEntry);
		if(newPosition==1){
			newNode->setNext(headPtr);
			headPtr = newNode;
		}else{
			Node<T>* last = getNodeAt(newPosition-1);
			newNode->setNext(last->getNext());
			last->setNext(newNode);
		}
		itemCount++;
	}else{
		throw PrecondViolatedExcep("Invalid position!\n");
	}
}

template <class T>
Node<T>* List<T>::getNodeAt(int position)const{
	Node<T> * curr = headPtr;
	if(position>=1&&position<=itemCount){
		for(int i=1;i< position;i++){
			curr = curr->getNext();
		}
	}
	return curr;
}

template <class T>
void List<T>::remove(int pos) throw(PrecondViolatedExcep){
bool ableToRemove = (pos>=1)&&(pos<=itemCount);
if(ableToRemove){
	Node<T>* curr = nullptr;
	if(pos==1){
		curr = headPtr;
		headPtr = headPtr->getNext();
	}else{
		Node<T>* last = getNodeAt(pos-1);
		curr = last->getNext();
		last->setNext(curr->getNext());
	}
	curr->setNext(nullptr);
	delete curr;
	curr = nullptr;
	itemCount--;
}else{
	throw PrecondViolatedExcep("Invalid position!\n");
}

}

template <class T>
void List<T>::clear(){
while(isEmpty()){
	remove(1);
}
}

template <class T>
T List<T>::getEntry(int pos) const throw(PrecondViolatedExcep){
if(pos>=1 && pos<=getLength()){
	return getNodeAt(pos)->getItem();
}else{
	throw PrecondViolatedExcep("Invalid position!\n");
}

}

template <class T>
void List<T>::setEntry(int pos,const T& newEntry) throw(PrecondViolatedExcep){
if(pos>=1 && pos <=getLength()){
	Node<T>* curr = getNodeAt(pos);
	curr->setItem(newEntry);
}else{
	throw PrecondViolatedExcep("Invalid Position!\n");
}
}
/*
template <class T>
Node<T>* getCurrent(){return current;}
*/

template <class T>
List<T>& List<T>::operator=(const List<T>& aList){
	if(this ==&aList){
		return *this;
	}else{
	itemCount = aList.itemCount;
	Node<T>* origin = aList.headPtr;
	if(origin ==nullptr){
		headPtr = nullptr;
	}else{
		//copy first Node
		headPtr = new Node<T>();
		headPtr->setItem(origin->getItem());
		//last-node pointer  copy remaing nodes
		Node<T>* newChainPtr = headPtr;
		while(origin !=nullptr){
			Node<T>* newChainPtr = origin->getNext();
			T nextItem = origin->getItem();
			Node<T>* newNode = new Node<T>(nextItem);
			newChainPtr->setNext(newNode);
			newChainPtr = newChainPtr->getNext();
		}
		newChainPtr->setNext(nullptr);
	}
	return *this;
  }
}
/*
template <class T>
T List<T>::getEntry(const T& itemName)throw(PrecondViolatedExcep){
	bool flag = false;
	for(int i=1;i<itemCount;i++){
		if(getEntry(i)==itemName){
			flag = true;
			return getEntry(i);
		}
	}
	if(flag = false){
		throw ("Do not find target!\n");
	}

}
*/
