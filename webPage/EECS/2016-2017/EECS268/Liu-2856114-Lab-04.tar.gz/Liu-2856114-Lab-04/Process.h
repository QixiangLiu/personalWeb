#ifndef PROCESS_H
#define PROCESS_H
#include "Stack.h"
#include <iostream>

class Process{
private:
  std::string name;
  Stack<std::string>* method;
public:
  Process(); //constructor
  Process(std::string proName);

  bool emptyStack();
  std::string getProcessName()const;//actutar function
  /*
  pre: have a stack of method
  post: add a string function to stack
  return none;
  */

  void pushMethod(std::string func); //add method
  /*
    get function
    post: the stack will probably be empty
    parm: string type
    return: string
  */

  std::string getFunction()const;
  /*
    pre: none
    post: the stack will probably be empty
    param: none
    return: none/void
  */
  void popMethod(); //remove;
};

#endif
