//Executive.h
#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include <iostream>
#include <string>
#include <fstream>
#include "Browser.h"
using namespace std;
class Executive{
public:
  Executive(string file);
  void run();
private:
  Browser myHis;
  string command;
  string filename;
  string url;
};

#endif
