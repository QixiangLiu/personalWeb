//Executive.cpp
#include "Executive.h"
Executive::Executive(string file):filename(file){

}

void Executive::run(){
  ifstream inFile;
  inFile.open(filename);
  if(!inFile){
    cout << "No input file name!\n";
    exit(0);
  }
  while(true){
    inFile >>command;
    if(inFile.eof()==true){
      break;
    }
    if(command== "NAVIGATE"){
      inFile>>url;
      myHis.navigateTo(url);
    }else if(command =="BACK"){
      myHis.back();
    }else if(command =="FORWARD"){
      myHis.forward();
    }else if(command =="HISTORY"){
      myHis.copyCurrentHistory();
    }else{
      cout << "Command is wrong!\n";
    }
    if(inFile.eof()==true){
      break;
    }
  }
  inFile.close();
}
