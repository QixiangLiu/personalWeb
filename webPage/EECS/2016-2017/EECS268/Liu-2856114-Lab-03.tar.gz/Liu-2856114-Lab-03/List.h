#ifndef LIST_H
#define LIST_H
#include "Node.h"
#include "PrecondViolatedExcep.h"
template <class T>
class List{
private:
	Node<T>* headPtr;
	int itemCount;
	Node<T>* getNodeAt(int position)const;
public:
	List();
	List(const List<T>& aList); //copy constructor
	~List();
	bool isEmpty()const;
	int getLength()const;
	void insert(int newPosition,const T& newEntry) throw(PrecondViolatedExcep);
	void remove(int pos) throw(PrecondViolatedExcep);
	void clear();
	T getEntry(int position)const throw(PrecondViolatedExcep);
	void setEntry(int pos, const T& newEntry) throw(PrecondViolatedExcep);


};
#include "List.cpp"
#endif
