#include "Browser.h"

Browser::Browser():myList(nullptr),count(1){
	myList = new List<string>();
}

Browser::~Browser(){
	delete myList;
}

string Browser::current()const{
	return myList->getEntry(count);
}
void Browser::navigateTo(string url){
	if(myList->isEmpty()){
		myList->insert(1,url);
	}else{
		if(count ==1){
			myList->insert(1,url);
		}else{
			myList->setEntry(count-1,url);
			for(int i=1;i<count-1;i++){
				myList->remove(1);
			}
		}
	}
	count =1;
}

void Browser::forward(){
	if(count !=1){
		count--;
	}
}
void Browser::back(){
	if(count != myList->getLength()){
		count++;
	}
}

void Browser::copyCurrentHistory(){
	int length = myList->getLength();
cout << "Oldest\n"
		 << "===============\n";
		 for(int i=length;i>=1;i--){
			 cout << myList->getEntry(i);
			 if(myList->getEntry(i)==current()){
				 cout << "\t <==current";
			 }
			 cout << endl;
		 }
cout << "===============\n"
		 << "Newest\n\n";


}
