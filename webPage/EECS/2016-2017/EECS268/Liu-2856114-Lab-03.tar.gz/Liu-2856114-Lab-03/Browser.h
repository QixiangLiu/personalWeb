#ifndef BROWSER_H
#define BROWSER_H
#include "List.h"
#include <string>
#include <iostream>
using namespace std;
class Browser{
public:
	Browser();
	~Browser();
	void navigateTo(string url);
	void forward();
	void back();
	string current()const;
	void copyCurrentHistory();
private:
	List<string>* myList;
	int count;
};

#endif
