/*
File name: main.cpp
Author:Qixiang Liu
Assingment: eecs268 Lab3
Date: 09/19/2017
*/

#include <iostream>
#include "Executive.h"
using namespace std;
int main(int argc, char* argv[]){
 if(argc <2){
        cout <<"Incorrect Number.\n";
  }else{
    Executive myExc("input.txt");
    myExc.run();
  }


return 0;
}
