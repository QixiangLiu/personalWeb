#ifndef PRECOND_VIOLATED_EXCEP_H
#define PRECOND_VIOLATED_EXCEP_H
#include <stdexcept>
#include <iostream>
class PrecondViolatedExcep : public std::runtime_error{
public:
	PrecondViolatedExcep(const std::string& msg=""):std::runtime_error(msg.c_str()){}
};

#endif
