//include Sort.hpp
#include <cassert>
#include <iostream>
using namespace std;
template <class T>
void Sort<T>::bubbleSort(T arr[],int size){
  bool sorted = false;
  int pass =1;
  while(!sorted && (pass<size)){
    sorted = true;
    for(int i=0;i<size-pass;i++){
      if(arr[i]>arr[i+1]){
        T temp = arr[i];
        arr[i] = arr[i+1];
        arr[i+1] = temp;
        sorted = false;
      }
    }
    /* assert
    for(int i=0;i<size-pass;i++){
      assert(arr[i]<arr[size-pass]);
    }
    */
    pass++;
  }
  //assert(Sort<T>::isSort(arr,size));
}
template <class T>
void Sort<T>::selectionSort(T arr[], int size){
  for(int i=size-1;i>=1;i--){
      //find largest value
    int largestIndex = 0;
      
    for(int j=1;j<i+1;j++){
      if(arr[largestIndex]<arr[j]){
          largestIndex = j;
      }
    }
      //swap last
      T temp = arr[largestIndex];
      arr[largestIndex] = arr[i];
      arr[i] = temp;
  }
  //assert(Sort<T>::isSort(arr,size));
}

template <class T>
void Sort<T>::insertionSort(T arr[],int size){
  for(int i=1;i<size;i++){
    T next = arr[i];
    int loc =i;
    while(loc >0 && arr[loc-1]>next){
      arr[loc] = arr[loc-1];
      loc--;
    }
    arr[loc] = next;
  }
  //assert(Sort<T>::isSort(arr,size));

}

template <class T>
void Sort<T>::mergeSort(T arr[],int size){
    if(size<2){
        return;
    }else{
        int mid = size-size/2;
        T left[mid];
        T right[size-mid];
        for(int i=0;i<mid;i++){
                left[i] = arr[i];
        }
        for(int i=mid;i<size;i++){
            right[i-mid] = arr[i];
        }
        mergeSort(left,mid);
        mergeSort(right,size-mid);
        merge(left,right,mid,size-mid);
        for(int i=0;i<size;i++){
            if(i<mid){
                arr[i] = left[i];
            }else{
                arr[i] = right[i-mid];
            }
        }

    }
    //assert(Sort<T>::isSort(arr,size));

}

template <class T>
void Sort<T>::merge(T* a1,T* a2,int size1,int size2){
    int size = size1+size2;
    T arr[size];
    int i =0,j=0,k=0;
    while(i<size1&&j<size2){
        if(a1[i]<=a2[j]){
            arr[k++] = a1[i++];
        }else{
            arr[k++] = a2[j++];
        }
    }

    while(i<size1){
        arr[k++] = a1[i++];
    }
    while(j<size2){
        arr[k++] = a2[j++];
    }
    for(i=0;i<size;i++){
        if(i<size1){
            a1[i] = arr[i];
        }else{
            a2[i-size1]= arr[i];
        }
    }
}
//quickSort
template <class T>
void Sort<T>::quickSort(T arr[],int size){
  quickSortRec(arr,0,size-1,false);
  //assert(Sort<T>::isSort(arr,size));

}

template <class T>
void Sort<T>::quickSortWithMedian(T arr[],int size){
  quickSortRec(arr,0,size-1,true);
  //assert(Sort<T>::isSort(arr,size));

}

template <class T>
void Sort<T>::quickSortRec(T arr[],int first,int last,bool median){
    
 // if(last-first+1<3){
 //   insertionSort(arr,last+1);
 //   return;
 // }else
      if(first < last){
    int pivot = partition(arr,first,last,median);
    quickSortRec(arr,first,(pivot-1),median);
    quickSortRec(arr,(pivot+1),last,median);
    return;
  }

}

template <class T>
void Sort<T>::setMedianPivot(T arr[], int first, int last){
  int mid = first + (last-first)/2;
  /*
  T temp[]={arr[first],arr[mid],arr[last]};
  selectionSort(temp,3);
  arr[first]=temp[0];
  arr[mid] = temp[1];
  arr[last] = temp[2];
*/
  if(arr[first]>arr[mid]){
    T temp = arr[first];
    arr[first] = arr[mid];
    arr[mid] = temp;
  }
  if(arr[mid]>arr[last]){
    T temp = arr[mid];
    arr[mid] = arr[last];
    arr[last] = temp;
  }
  if(arr[first]>arr[mid]){
    T temp = arr[first];
    arr[first] = arr[mid];
    arr[mid] = temp;
  }

}

template <class T>
int Sort<T>::partition(T arr[],int first,int last,bool median){
  if(median ==true){
    int pivotIndex = first+(last-first)/2;
    setMedianPivot(arr,first,last);
    //swap piovt last-1
    T temp = arr[pivotIndex];
    arr[pivotIndex] = arr[last-1];
    arr[last-1] = temp;

    pivotIndex = last-1;
    T pivot = arr[pivotIndex];
    int indexFromLeft = first+1;
    int indexFromRight = last-2;
    bool flag = false;
    while(!flag){
      while(arr[indexFromLeft] < pivot){
        indexFromLeft++;
      }
      while(arr[indexFromRight]>pivot){
        indexFromRight--;
      }
      if(indexFromLeft<indexFromRight){
        T temp = arr[indexFromLeft];
        arr[indexFromLeft]=arr[indexFromRight];
        arr[indexFromRight] = temp;
        indexFromLeft++;
        indexFromRight--;
      }else{
        flag = true;
      }

    }//end while
    //swap
      temp = arr[indexFromLeft];
      arr[indexFromLeft] = arr[pivotIndex];
      arr[pivotIndex] = temp;
      pivotIndex = indexFromLeft;
      return pivotIndex;

  }else{
    int pivotIndex = last;
    int indexFromLeft =first;
    int indexFromRight = last-1;
    T pivot = arr[pivotIndex];
    while(indexFromLeft<indexFromRight){
      while(arr[indexFromLeft] < pivot){
        indexFromLeft++;
      }
      while(arr[indexFromRight]>pivot){
        indexFromRight--;
      }
      if(indexFromLeft<indexFromRight){
        T temp = arr[indexFromLeft];
        arr[indexFromLeft]=arr[indexFromRight];
        arr[indexFromRight] = temp;
        indexFromLeft++;
        indexFromRight--;
      }



    }//end while
    T temp = arr[last];
    arr[last] = arr[indexFromLeft];
    arr[indexFromLeft] = temp;
      return indexFromLeft;
  }
}

template <class T>
bool Sort<T>::isSort(T arr[],int size){
  if(size==1){
    return true;
  }else{
    for(int i=0;i<size-1;i++){
      if(arr[i]>arr[i+1]){
        return false;
      }
    }
    return true;
  }
}
