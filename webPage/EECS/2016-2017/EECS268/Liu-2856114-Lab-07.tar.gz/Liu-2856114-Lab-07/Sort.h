#ifndef SORT_H
#define SORT_H

template <class T>
class Sort{
public:
  /** Sorts the items in an array into ascending order.
 @pre  None.
 @post  theArray is sorted into ascending order; n is unchanged.
 @param theArray  The given array.
 @param n  The size of theArray. */
  static void bubbleSort(T arr[],int size);
  /** Sorts the items in an array into ascending order.
 @pre  None.
 @post  The array is sorted into ascending order; the size of the array
    is unchanged.
 @param theArray  The array to sort.
 @param n  The size of theArray. */
  static void selectionSort(T arr[], int size);
  /** Sorts the items in an array into ascending order.
 @pre  None.
 @post  theArray is sorted into ascending order; n is unchanged.
 @param theArray  The given array.
 @param n  The size of theArray. */
  static void insertionSort(T arr[],int size);
  static void mergeSort(T arr[],int size);
  static void quickSort(T arr[],int size);
  static void quickSortWithMedian(T arr[], int size);
  static bool isSort(T arr[],int size);
private:
  static void merge(T* a1,T* a2,int size1, int size2);
  static void quickSortRec(T arr[],int first,int last,bool median);
  static void setMedianPivot(T arr[],int first, int last);
  static int partition(T arr[],int first, int last,bool median);

};
#include "Sort.hpp"
#endif
