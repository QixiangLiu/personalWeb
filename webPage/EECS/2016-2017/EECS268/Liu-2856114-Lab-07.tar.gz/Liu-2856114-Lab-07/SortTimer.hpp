//SortTimer.cpp
template <class T>
double SortTimer<T>::Timer(std::function<void(T[],int)> sort,T arr[],int size){
  clock_t t;
  t = clock();
  sort(arr,size);
  t = clock() - t;
  //printf ("It took me %d clicks (%f seconds).\n",(int)t,((float)t)/CLOCKS_PER_SEC);
  return ((float)t/CLOCKS_PER_SEC);

}
