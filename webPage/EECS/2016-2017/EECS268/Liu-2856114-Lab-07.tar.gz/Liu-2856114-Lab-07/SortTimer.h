#ifndef SORT_TIMER_H
#define SORT_TIMER_H
#include <iostream>
#include <time.h>
#include <functional>
#include "Sort.h"
#include <stdio.h>
using namespace std;
template <class T>
class SortTimer{

public:
  static double Timer(std::function<void(T[],int)> sort, T arr[],int size);
};

#include "SortTimer.hpp"

#endif
