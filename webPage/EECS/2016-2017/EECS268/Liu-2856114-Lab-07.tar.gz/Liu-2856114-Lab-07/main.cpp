/*
file name: main.cpp
Author: Qixiang Liu
KUID:2856114
Homework: EECS268 Lab07
Description: use different kinds of sort to calculate their time
Due Data: 2017 October 30
*/

#include <iostream>
#include "SortTimer.h"
#include "Sort.h"
#include <string>
#include <time.h>
#include <fstream>
#include <stdlib.h>
#include <cassert>
#include <stdio.h>
using namespace std;
int main(int argc,char* argv[]){
if(argc<6){
  cout <<"Wrong command!\n";
}else{
  ofstream OutFile;
  OutFile.open(argv[5]);
  double SortTime =0;
  string name = argv[1];
  //string flag2 = argv[6];
  int sizeFrom = stoi(argv[2]);
  int sizeTo = stoi(argv[3]);
  int step = stoi(argv[4]);
  bool flag = false;
  
    if(argv[6] == "assert"){
    	flag = true;
    }else{
	flag = false;
	}

  
OutFile << name<<"\n";
while(sizeFrom<=sizeTo){
  srand(time(NULL));
  int arr[sizeFrom];
  for(int i=0;i<sizeFrom;i++){
    arr[i] = rand();
  }
  if(name == "bubble"){
    SortTime = SortTimer<int>::Timer(Sort<int>::bubbleSort,arr,sizeFrom);
    cout << sizeFrom <<","<<SortTime<<endl;
    if(flag == true){
      assert(Sort<int>::isSort(arr,sizeFrom));
    }
  }else if(name == "selection"){
    SortTime = SortTimer<int>::Timer(Sort<int>::selectionSort,arr,sizeFrom);
    cout << sizeFrom <<","<<SortTime<<endl;
    if(flag == true){
      assert(Sort<int>::isSort(arr,sizeFrom));
    }
  }else if(name == "insertion"){
    SortTime = SortTimer<int>::Timer(Sort<int>::insertionSort,arr,sizeFrom);
    cout << sizeFrom <<","<<SortTime<<endl;
    if(flag == true){
      assert(Sort<int>::isSort(arr,sizeFrom));
    }
  }else if(name == "merge"){
    SortTime = SortTimer<int>::Timer(Sort<int>::mergeSort,arr,sizeFrom);
    cout << sizeFrom <<","<<SortTime<<endl;
    if(flag == true){
      assert(Sort<int>::isSort(arr,sizeFrom));
    }
  }else if(name == "quick"){
    SortTime = SortTimer<int>::Timer(Sort<int>::quickSort,arr,sizeFrom);
    cout << sizeFrom <<","<<SortTime<<endl;
    if(flag == true){
      assert(Sort<int>::isSort(arr,sizeFrom));
    }
  }else if(name == "quickWithMedian"){
    SortTime = SortTimer<int>::Timer(Sort<int>::quickSortWithMedian,arr,sizeFrom);
    cout << sizeFrom <<","<<SortTime<<endl;
    if(flag == true){
      assert(Sort<int>::isSort(arr,sizeFrom));
    }
  }else{
    cout << "Wrong sort name!\n ";
    break;
  }
  OutFile <<sizeFrom <<","<<SortTime<<"\n";
  sizeFrom = sizeFrom+step;

}
  OutFile.close();

}

//SortTimer<string>::Timer(Sort<string>::selectionSort,a,6);


  return 0;
}
