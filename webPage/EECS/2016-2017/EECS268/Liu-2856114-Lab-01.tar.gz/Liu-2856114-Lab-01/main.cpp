/*
File Name: main.cpp
Author: Qixiang Liu
Assignment: EECS268 lab01
Date: Mon 28 Aug 2017 03:26:28 PM CDT 
*/

#include <iostream>
#include "Executive.h"
using namespace std;

int main(int argc,char* argv[]){
    
    if(argc <2){
        cout << "Incorrect Number.\n";
    }else{
        Executive myExec(argv[1]);
        myExec.run();
    }

    
return 0;
}
