// Executive.h

#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include "FantasyFootball.h"
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <limits>
using namespace std;
class Executive{
public:
	Executive(string file);
	~Executive();
	void run();
	
private:
	int size;
	FantasyFootball** myFF;
	/*
	precondition: None
	postcondition: None
	it is a menu to display
	*/
    void menu();
	/*
	precondition: None
	postcondition: None
	it is a interaction 1 with user to print entire information.
	*/
    void interaction1();
/*
	precondition: a string type of Team initials of inputs
	postcondition: None
	it is a interaction 2 with user to print specific information given Team initials.
	*/
    void interaction2(string ini);
/*
	precondition: A range of 1-79 ranks of Football
	postcondition: None
	it is a interaction 3 with user to print domain of information;
	*/
    void interaction3(int fromRank,int toRank);
/*
	precondition: Look for Drafted people, not -1;
	postcondition: A new element is Rank VS ADP
	it is a interaction 4 with user to print drafted football players.
	*/
    void interaction4();
/*
	precondition: an argument is filename as an output.
	postcondition: close the file.
	it is a interaction 5 with user to store information to txt or dat.
	*/
    void interaction5(string file);



};

#endif
