#ifndef FANTASYFOOTBALL_H
#define FANTASYFOOTBALL_H
#include <iostream>
using namespace std;

class FantasyFootball{
public:
	FantasyFootball(int r,string f,string l,string ini,int bye,int adp);
	~FantasyFootball();
    int getRank()const;			//get Function to rank; return integer
    string getFirst()const;		//get Function to First name; return string
    string getLast()const;		//get Function to Last name; return string
    string getInitials()const;		//get Function to Team initals; return string
    int getBye()const;			//get Function to Bye Week; return integer
    int getAdp()const;			//get Function to ADP; return integer
   

private:
	int rank;
    string first;
    string last;
	string initials;
    int byeWeek;
    int ADP;

};
#endif
