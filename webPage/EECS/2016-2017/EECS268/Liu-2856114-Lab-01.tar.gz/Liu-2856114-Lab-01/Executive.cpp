//Executive.cpp

#include "Executive.h"
Executive::Executive(string file):size(0),myFF(nullptr){
    string name,last,first,ini;
    int adp,byeWeek,rank;
    ifstream InFile;
    InFile.open(file);
	if(!InFile){
		cout << "file open failed.\n";
		exit(0);
	}
    InFile >> size;
    myFF = new FantasyFootball*[size];
    for(int i=0;i<size;i++){
        
        getline(InFile,name,',');
        rank = stoi(name);
        getline(InFile,name,',');
        size_t found = name.find(' ');
        first = name.substr(0,found);
        size_t found2 = name.find(' ',found+1);
        last =  name.substr(found+1,found2-found-1);
        ini = name.substr(found2+1);
        getline(InFile,name,',');
        byeWeek = stoi(name);
        getline(InFile,name);
        adp =stoi(name);
        myFF[i] = new FantasyFootball(rank,first,last,ini,byeWeek,adp);
    }
    InFile.close();
}

Executive::~Executive(){
    for(int i=0;i<size;i++)
        delete myFF[i];
    delete[] myFF;
}

void Executive::menu(){
	cout << "1) Print the entire list of quarterbacks. \n"
	     << "2) Print all quarterbacks on a particular team.\n"
	     << "3) Print all quarters between to ranks. \n"
	     << "4) Print all drafted quarterbacks first name,last name, rank,ADP,and Rank VS ADP. \n"
	     << "5) Creat a file with the current information of drafted quarterbacks and Rank VS ADP.\n"
         << "6) Exit \n"
	     << "Enter a choice: ";
}

void Executive::Executive::run(){
    int choice =0,exit=0;
    string filename;
    int from =0,to=0;
    string team;
	
    while(exit!=6){
        menu();
        cin >> choice;
        while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << "Sorry, your input did not seem to be int. Try again: ";
            cin >> choice;
        }
        if(choice ==1){
            interaction1();
        }else if(choice==2){
            cout << "Enter a team name: ";
            cin >> team;
            interaction2(team);
        }else if(choice ==3){
            cout << "Enter the rank from ...to...: ";
            cin >> from >> to;
	while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << "Sorry, your input did not seem to be int. Try again: from...to...:";
            cin >> from >> to;
        }
            interaction3(from,to);
        }else if(choice ==4){
            interaction4();
        }else if(choice ==5){
            cout << "Enter a filename as a output: ";
            cin >> filename;
            interaction5(filename);
        }else if(choice ==6){
            exit =6;
        }else{
            cout << "Wrong number to choice!\n";
        }
    }
}

void Executive::interaction1(){
    cout << "rank \tName \t\t\tTeam\tBye\tADP\t \n";
    for(int i=0;i<size;i++){
        cout <<"<"<<myFF[i]->getRank()<<">.\t"
             <<setw(9)<<left<<myFF[i]->getFirst()
             <<setw(15)<<left<<myFF[i]->getLast()
             <<setw(3)<<right<<myFF[i]->getInitials()<<"\t"
             <<myFF[i]->getBye()<<"\t"
             <<myFF[i]->getAdp()<<"\n";
        
    }
}

void Executive::interaction2(string ini){
    bool flag = false;
    for(int i=0;i<size;i++){
        if(myFF[i]->getInitials() == ini){
            cout <<"<"<<myFF[i]->getRank()<<">.\t"
            <<setw(9)<<left<<myFF[i]->getFirst()
            <<setw(15)<<left<<myFF[i]->getLast()
            <<setw(3)<<right<<myFF[i]->getInitials()<<"\t"
            <<myFF[i]->getBye()<<"\t"
            <<myFF[i]->getAdp()<<"\n";
            flag = true;
        }
    }
    if(flag == false){
        cout << "No this team: \n";
    }
}

void Executive::interaction3(int fromRank,int toRank){
    if(fromRank>0&&fromRank<=size&&toRank>0&&toRank<=size){
    cout << "rank \tName \t\t\tTeam\tBye\tADP\t \n";
        for(int i=fromRank-1;i<toRank;i++){
            cout <<"<"<<myFF[i]->getRank()<<">.\t"
            <<setw(9)<<left<<myFF[i]->getFirst()
            <<setw(15)<<left<<myFF[i]->getLast()
            <<setw(3)<<right<<myFF[i]->getInitials()<<"\t"
            <<myFF[i]->getBye()<<"\t"
            <<myFF[i]->getAdp()<<"\n";
        }
    }else{
        cout << "Wrong range!\n";
    }
}

void Executive::interaction4(){
    cout << "rank \tName \t\t\tTeam\tBye\tADP\tRank VS ADP\n";
    for(int i=0;i<size;i++){
        if(myFF[i]->getAdp()!=-1){
            cout <<"<"<<myFF[i]->getRank()<<">.\t"
            <<setw(9)<<left<<myFF[i]->getFirst()
            <<setw(15)<<left<<myFF[i]->getLast()
            <<setw(3)<<right<<myFF[i]->getInitials()<<"\t"
            <<myFF[i]->getBye()<<"\t"
            <<myFF[i]->getAdp()<<"\t"
            <<myFF[i]->getAdp()-myFF[i]->getRank()<<"\n";
        }
        
    }
}

void Executive::interaction5(string file){
    string store;
    ofstream outFile;
    outFile.open(file);
    store = "Rank \tname \t\t\t\tteam \tADP \tRank VS ADP\n";
    outFile << store;
    for(int i=0;i<size;i++){
        if(myFF[i]->getAdp()!=-1){
            store ="<"+to_string(myFF[i]->getRank())+">.\t<"+myFF[i]->getFirst()+"> <"+myFF[i]->getLast()+">            \t<"+myFF[i]->getInitials()+"> \t<"+to_string(myFF[i]->getAdp())+"> \t"+to_string(myFF[i]->getAdp()-myFF[i]->getRank())+"\n";
            outFile << store;

        }
    }
    outFile.close();
}



