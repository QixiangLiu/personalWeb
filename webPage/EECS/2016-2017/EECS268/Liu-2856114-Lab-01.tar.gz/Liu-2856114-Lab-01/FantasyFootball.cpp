//FantasyFootball.cpp


#include "FantasyFootball.h"

//constructor
FantasyFootball::FantasyFootball(int r,string f,string l,string ini,int bye,int adp):rank(r),first(f),last(l),initials(ini),byeWeek(bye),ADP(adp){}
//deconstructor
FantasyFootball::~FantasyFootball(){}

int FantasyFootball::getRank()const{return rank;}

string FantasyFootball::getFirst()const{return first;}

string FantasyFootball::getLast()const{return last;}

string FantasyFootball::getInitials()const{return initials;}

int FantasyFootball::getBye()const{return byeWeek;}

int FantasyFootball::getAdp()const{return ADP;}

