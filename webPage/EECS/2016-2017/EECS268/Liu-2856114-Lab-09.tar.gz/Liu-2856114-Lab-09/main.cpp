/*
file name: main.cpp
Author: Qixiang Liu
Homework: EECS268_lab9
Data: 11/27/17
*/


#include <iostream>
#include "Executive.h"

using namespace std;

int main(int argc,char** argv){
  if(argc <2){
    cout << "Wrong!\n";
  }else{
    Executive myExe(argv[1]);
    myExe.run();
  }

  return 0;
}
