//TreeTest.cpp
#include "TreeTest.h"

TreeTest::TreeTest(){
  //BST = new BinarySearchTree<string, VideoGame>();
}
TreeTest::~TreeTest(){
  //delete BST;
//BST = nullptr;
}

void TreeTest::testAdds(BinarySearchTree<string,VideoGame> bst){
  BinarySearchTree<string,VideoGame> BST = bst;
  string n,pl;
  double other;
  char choice ='0';
  do{
    cout << "Create Name, Platform, and one sales of Video Game \n";
    cout << "Name: ";
    cin.ignore(1);
    getline(cin,n);
    cout << "Platform: ";
    getline(cin,pl);
    cout << "number of sales: ";
    cin >> other;
    //cout << n <<pl<<other;
    VideoGame vg(n,pl,other);
    try{
      BST.add(vg,n);
      BST.inorderTraverse(print);
    }catch(DuplicateEntryError& de){
      cout <<"Error: "<< de.what();
    }
    cout << "Do you want to testAdds agains(y/n): ";
    cin >> choice;
  }while(choice != 'n'&&choice!='N');
}

void TreeTest::testRemoves(BinarySearchTree<string,VideoGame> bst){
  BinarySearchTree<string,VideoGame> BST = bst;
  string n;
  char choice ='0';
  do{
    cout << "remove one game (Name do not include double quotes):";
    cin.ignore(1,'\n');
    getline(cin,n);
    if(BST.contains(n)==true){
      BST.remove(n);
      BST.inorderTraverse(print);
    }else{
      cout << "Error: Not found\n";
    }
    cout << "Do you want to testRemoves again (y/n):";
    cin >> choice;
  }while(choice!='n'&&choice!='N');
}
