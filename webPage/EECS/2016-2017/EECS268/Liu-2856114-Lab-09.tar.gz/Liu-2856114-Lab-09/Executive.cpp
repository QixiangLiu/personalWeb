//Executive.cpp
#include "Executive.h"
Executive::Executive(){
  choice =0;
}
Executive::Executive(string name){
  filename = name;
  BST = new BinarySearchTree<string,VideoGame>();

}
Executive::~Executive(){
  delete BST;
  BST = nullptr;
}

void Executive::run(){
  int Exit =0;
  choice =0;
  string title;
  ifstream inFile;
  inFile.open(filename);
  if(!inFile){
    cout << "It is wrong name!\n";
    exit(0);
  }
  getline(inFile,title);
  //cout  <<title<<endl;
while(true){
  getline(inFile,mark,',');
  if(inFile.eof()){
    break;
  }
  if(mark=="N/A"){
    r =0;
  }else{
    r = stoi(mark);
  }
  getline(inFile,n,',');
  if(n[0]=='\"'){
    getline(inFile,n2,'"');
    n = n+","+n2;
    n = n.substr(1);
    inFile.ignore(1,',');
  }
  getline(inFile,pl,',');
  getline(inFile,mark,',');
  if(mark=="N/A"){
    y =0;
  }else{
    y = stoi(mark);
  }
  getline(inFile,g,',');
  getline(inFile,pu,',');
  getline(inFile,mark,',');
  NA = atof(mark.c_str());
  getline(inFile,mark,',');
  EU = atof(mark.c_str());
  getline(inFile,mark,',');
  JP = atof(mark.c_str());
  getline(inFile,mark,',');
  other = atof(mark.c_str());
  getline(inFile,mark);
  global = atof(mark.c_str());
  //cout << r<<" "<<n<<" "<<pl<<" "<<y<<" "<<g<<" "<<pu<<" "<<NA<<" "
    //   <<EU<<" "<<JP<<" "<<other<<" "<<global<<endl;
  VideoGame myVideo(r,n,pl,y,g,pu,NA,EU,JP,other,global);
  if(BST->contains(n)==false){
    BST->add(myVideo);
  }else{
    //cout << "Error: Dulplicate entry\n";
    //ignore dulplicate
  }
}
inFile.close();//end read file

do{
    menu();
    cin >> choice;
    while(cin.fail()){
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(),'\n');
      cin >>choice;
    }
    if(choice == 1){
      string videoName;
      cout << "Enter a name of Video games:";
      cin.ignore(1);
      getline(cin,videoName);
      VideoGame vg;
      try{
        vg = BST->getEntry(videoName);
        cout << "====================\n"
             << "<Name>: "<<videoName<<endl
             << "====================\n"
             << "\t <Platform>: "<< vg.getPlatform()<<endl
             << "\t <Year>: "<< vg.getYear()<<endl
             << "\t <Grenre>: "<< vg.getGenre()<<endl
             << "\t <Publisher>: "<< vg.getPublisher()<<endl
             << "\t <NA_sales>: "<< vg.getNA()<<endl
             << "\t <EU_sales>: "<< vg.getEU()<<endl
             << "\t <JP_sales>: "<< vg.getJP()<<endl
             << "\t <other_sales>: "<< vg.getOther()<<endl
             << "\t <global_sales>: "<< vg.getGlobal()<<endl;
      }catch(NotFoundException& e){
        cout << "Error: "<<e.what();
      }


    }else if(choice == 2){
      BST->inorderTraverse(print);

    }else if(choice ==3){
      Exit = 3;
    }else{
      cout << "Wrong! Enter correct choice: \n";
    }//end if
  }while(Exit!=3);//end phase 1
  cout << "\n=================================\n";
  cout << "Finish Phase one! Start Phase two!\n";
  cout << "===================================\n";
  //reset choice exit
  choice = 0;
  Exit =0;
  while(Exit!=4){
    menu2();
    cin >> choice;
    while(cin.fail()){
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(),'\n');
      cin >>choice;
    }
    if(choice == 1){
      cout << "Create Name, Platform, and one sales of Video Game \n";
      cout << "Name: ";
      cin.ignore(1);
      getline(cin,n);
      cout << "Platform: ";
      getline(cin,pl);
      cout << "number of sales: ";
      cin >> other;
      //cout << n <<pl<<other;
      VideoGame vg(n,pl,other);
      try{
        BST->add(vg,n);
      }catch(DuplicateEntryError& de){
        cout <<"Error: " <<de.what();
      }
    }else if(choice ==2){
      cout << "remove one game(Name do not includes double quotes):";
      cin.ignore(1,'\n');
      getline(cin,n);
      if(BST->contains(n)==true){
        BST->remove(n);
      }else{
        cout << "Error: Not found\n";
      }
    }else if(choice==3){
      int choice2 = 0;

      TreeTest myTree;
        cout << "Test Mode\n";
        cout << "1) testADD:\n";
        cout << "2) testRemoves: \n";
        cout << "Choice: ";
        cin >> choice2;
        while(cin.fail()){
          cin.clear();
          cin.ignore(numeric_limits<streamsize>::max(),'\n');
          cin >>choice2;
        }
        if(choice2 ==1){
          myTree.testAdds(*BST);
        }else{
          myTree.testRemoves(*BST);
        }
    }else if(choice ==4){
      Exit=4;
    }else{
      cout << "Wrong!Enter correct choice!\n";
    }
  }

}//end run()

void Executive::menu(){
  cout << "1) Search a specific name \n";
  cout << "2) Print All video games \n";
  cout << "3) Exit and Enter Phase 2 \n"
       << "Choice: ";
}

void Executive::menu2(){
  cout << "1) ADD a new game \n";
  cout << "2) Remove \n";
  cout << "3) Test \n";
  cout << "4) Exit \n"
       << "Choice: ";

}
