//VideoGame.cpp
#include "VideoGame.h"
//defaule constructor
VideoGame::VideoGame(){}

VideoGame::VideoGame(int R,string N,string PF,int Y,string G,string P,double NA,
  double EU,double JP,double other,double global){
    rank = R;
    name = N;
    platform = PF;
    year = Y;
    genre = G;
    publisher = P;
    NA_sales = NA;
    EU_sales = EU;
    JP_sales = JP;
    other_sales = other;
    global_sales = global;
  }

  VideoGame::VideoGame(string N,string PF,double other){
    name =N;
    platform = PF;
    other_sales = other;
    year = 0;
    genre = "unknown";
    publisher ="unknown";
    NA_sales = 0;
    EU_sales = 0;
    JP_sales = 0;
    global_sales = 0;
  }

  VideoGame::~VideoGame(){}

  string VideoGame::getName()const{ return name;}
  int VideoGame::getRank()const{return rank;}
  string VideoGame::getPlatform()const{return platform;}
  int VideoGame::getYear()const{return year;}
  string VideoGame::getGenre()const{return genre;}
  string VideoGame::getPublisher()const{return publisher;}
  double VideoGame::getNA()const{return NA_sales;}
  double VideoGame::getEU()const{return EU_sales;}
  double VideoGame::getJP()const{return JP_sales;}
  double VideoGame::getOther()const{return other_sales;}
  double VideoGame::getGlobal()const{return global_sales;}

  void VideoGame::setName(string N){name = N;}

  bool VideoGame::operator>(const VideoGame& vg)const{
    return name > vg.name;
  }
  bool VideoGame::operator==(const VideoGame& vg)const{
    return name == vg.name;
  }
  bool VideoGame::operator==(const string& Videoname)const{
    return name == Videoname;
  }
  bool VideoGame::operator>(const string& Videoname)const{
    return name > Videoname;
  }

  //Global stream operators


std::ostream& operator<<(std::ostream& os, const VideoGame& vg) {
    os << "====================\n"
       << "<Name>: "<<vg.getName()<<endl
       << "====================\n"
       << "\t <Platform>: "<< vg.getPlatform()<<endl
       << "\t <Year>: "<< vg.getYear()<<endl
       << "\t <Grenre>: "<< vg.getGenre()<<endl
       << "\t <Publisher>: "<< vg.getPublisher()<<endl
       << "\t <NA_sales>: "<< vg.getNA()<<endl
       << "\t <EU_sales>: "<< vg.getEU()<<endl
       << "\t <JP_sales>: "<< vg.getJP()<<endl
       << "\t <other_sales>: "<< vg.getOther()<<endl
       << "\t <global_sales>: "<< vg.getGlobal()<<endl;
    return os;
}
