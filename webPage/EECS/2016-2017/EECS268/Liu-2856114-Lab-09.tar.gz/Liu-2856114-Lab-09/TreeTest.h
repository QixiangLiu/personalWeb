#ifndef TREE_TEST_H
#define TREE_TEST_H
#include "BinarySearchTree.h"
#include <string>
#include <iostream>
#include "VideoGame.h"
#include "NotFoundException.h"
#include "PrecondViolatedExcep.h"
#include "DuplicateEntryError.h"

using namespace std;
class TreeTest{
public:
  TreeTest();
  ~TreeTest();
  void testAdds(BinarySearchTree<string,VideoGame> bst);
  void testRemoves(BinarySearchTree<string,VideoGame> bst);
  static void print(VideoGame& vg){cout << vg<<endl;}
  static void print(string& str){cout << str<<endl;}


};
#endif
