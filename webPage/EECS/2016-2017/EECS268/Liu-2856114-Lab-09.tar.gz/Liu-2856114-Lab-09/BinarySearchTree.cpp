//BinarySearchTree.cpp
//defalt Constructor
template<typename KeyType,typename ItemType>
BinarySearchTree<KeyType,ItemType>::BinarySearchTree():rootPtr(nullptr){}

template<typename KeyType,typename ItemType>
BinarySearchTree<KeyType,ItemType>::BinarySearchTree(const ItemType& rootItem){
  rootPtr = new BinaryNode<ItemType>(rootItem,nullptr,nullptr);
}
//copyConstructor
template<typename KeyType,typename ItemType>
BinarySearchTree<KeyType,ItemType>::BinarySearchTree(const BinarySearchTree<KeyType,ItemType>& tree){
  rootPtr = BinaryNodeTree<ItemType>::copyTree(tree.rootPtr);
}

template<typename KeyType,typename ItemType>
bool BinarySearchTree<KeyType,ItemType>::isEmpty()const{return rootPtr==nullptr;}

template<typename KeyType,typename ItemType>
ItemType BinarySearchTree<KeyType,ItemType>::getRootData()const throw(PrecondViolatedExcep){
  if(isEmpty()){
    throw PrecondViolatedExcep("Empty root!\n");
  }else{
    return rootPtr->getItem();
  }
}
//deconstructor
template<typename KeyType,typename ItemType>
BinarySearchTree<KeyType,ItemType>::~BinarySearchTree(){
 clear();
}
template<typename KeyType,typename ItemType>
void BinarySearchTree<KeyType,ItemType>::setRootData(const ItemType& newData)const throw(PrecondViolatedExcep){
  if(isEmpty()){
    throw PrecondViolatedExcep("Empty root!\n");
  }else{
    rootPtr->setItem(newData);
  }
}
template<typename KeyType,typename ItemType>
void BinarySearchTree<KeyType,ItemType>::preorderTraverse(void visit(ItemType&))const{
  BinaryNodeTree<ItemType>::preorder(visit,rootPtr);
}
template<typename KeyType,typename ItemType>
void BinarySearchTree<KeyType,ItemType>::inorderTraverse(void visit(ItemType&))const{
  BinaryNodeTree<ItemType>::inorder(visit,rootPtr);
}

template<typename KeyType,typename ItemType>
void BinarySearchTree<KeyType,ItemType>::postorderTraverse(void visit(ItemType&))const{
  BinaryNodeTree<ItemType>::postorder(visit,rootPtr);
}
//getHeight
template<typename KeyType,typename ItemType>
int BinarySearchTree<KeyType,ItemType>::getHeight()const{
  return BinaryNodeTree<ItemType>::getHeightHelper(rootPtr);
}
//insertInorder helper
template<typename KeyType,typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType,ItemType>::insertInorder(BinaryNode<ItemType>* subTreePtr,BinaryNode<ItemType>* newNode){

  if(subTreePtr==nullptr){
    return newNode;
  }else if(subTreePtr->getItem()>newNode->getItem()){
    BinaryNode<ItemType>* temp = insertInorder(subTreePtr->getLeftChildPtr(),newNode);
    subTreePtr->setLeftChildPtr(temp);
  }else{
    BinaryNode<ItemType>* temp = insertInorder(subTreePtr->getRightChildPtr(),newNode);
    subTreePtr->setRightChildPtr(temp);
  }
  return subTreePtr;
}
// add ItemType
template<typename KeyType,typename ItemType>
bool BinarySearchTree<KeyType,ItemType>::add(const ItemType& newEntry)
{
    BinaryNode<ItemType>* newNode = new BinaryNode<ItemType>(newEntry);
    rootPtr = insertInorder(rootPtr,newNode);
    return true;

}
template<typename KeyType,typename ItemType>
bool BinarySearchTree<KeyType,ItemType>::add(const ItemType& newEntry,const KeyType& key) throw(DuplicateEntryError)
{
    if(contains(key)==true){
      throw DuplicateEntryError("Have created video game\n");
    }else{
      BinaryNode<ItemType>* newNode = new BinaryNode<ItemType>(newEntry);
      rootPtr = insertInorder(rootPtr,newNode);
      return true;
    }

}
//remove Value
template<typename KeyType,typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType,ItemType>::removeValue(BinaryNode<ItemType>* subTreePtr,KeyType target,bool& success){
  if(subTreePtr==nullptr){
    success = false;
    return nullptr;
  }else if(subTreePtr->getItem()==target){
    subTreePtr = removeNode(subTreePtr);
    success = true;
    return subTreePtr;
  }else if(subTreePtr->getItem()>target){//left
    BinaryNode<ItemType>* temp = removeValue(subTreePtr->getLeftChildPtr(),target,success);
    subTreePtr->setLeftChildPtr(temp);
    return subTreePtr;
  }else{
    BinaryNode<ItemType>* temp = removeValue(subTreePtr->getRightChildPtr(),target,success);
    subTreePtr->setRightChildPtr(temp);
    return subTreePtr;
  }
}
//removeNode
template<typename KeyType,typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType,ItemType>::removeNode(BinaryNode<ItemType>* nodePtr){
  if(nodePtr->isLeaf()==true){
    delete nodePtr;
    nodePtr = nullptr;
    return nodePtr;
  }else if((nodePtr->isLeaf()==false)&&((nodePtr->getLeftChildPtr()==nullptr)||(nodePtr->getRightChildPtr()==nullptr))){  //only one child
    BinaryNode<ItemType>* BinaryNodeNext = nullptr;
    if(nodePtr->getLeftChildPtr()!=nullptr){
       BinaryNodeNext = nodePtr->getLeftChildPtr();
    }else{
      BinaryNodeNext = nodePtr->getRightChildPtr();
    }
    delete nodePtr;
    nodePtr = nullptr;
    return BinaryNodeNext;
  }else{  //two child
    ItemType newNodeValue;
    BinaryNode<ItemType>* temp = removeLeftmostNode(nodePtr->getRightChildPtr(),newNodeValue);
    nodePtr->setRightChildPtr(temp);
    nodePtr->setItem(newNodeValue);
    return nodePtr;
  }


}

template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType,ItemType>::removeLeftmostNode(BinaryNode<ItemType>* subTreePtr,ItemType& inorderSuccessor){
  if(subTreePtr->getLeftChildPtr()==nullptr){
    inorderSuccessor = subTreePtr->getItem();
    return removeNode(subTreePtr);
  }else{
    return removeLeftmostNode(subTreePtr->getLeftChildPtr(),inorderSuccessor);
  }
}
//findNode
template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType,ItemType>::findNode(BinaryNode<ItemType>* treePtr,KeyType key)const{
  if(treePtr ==nullptr){
    return nullptr;
  }else if(treePtr->getItem()==key){
    return treePtr;
  }else if(treePtr->getItem()>key){
    return findNode(treePtr->getLeftChildPtr(),key);
  }else{
    return findNode(treePtr->getRightChildPtr(),key);
  }
}
// remove
template<typename KeyType,typename ItemType>
bool BinarySearchTree<KeyType,ItemType>::remove(const KeyType& anEntry){
  bool success = false;
  rootPtr = removeValue(rootPtr,anEntry,success);
  return success;
}

template<typename KeyType,typename ItemType>
ItemType BinarySearchTree<KeyType,ItemType>::getEntry(const KeyType& anEntry) const throw(NotFoundException){
  BinaryNode<ItemType>* target = findNode(rootPtr,anEntry);
  if(target ==nullptr){
    throw NotFoundException("Not find target!\n");
  }else{
    return target->getItem();
  }
}

template<typename KeyType,typename ItemType>
int BinarySearchTree<KeyType,ItemType>::getNumberOfNodes()const{
  return BinaryNodeTree<ItemType>::getNumberOfNodesHelper(rootPtr);
}

template<typename KeyType,typename ItemType>
void BinarySearchTree<KeyType,ItemType>::clear(){
  BinaryNodeTree<ItemType>::destroyTree(rootPtr);
}

template<typename KeyType,typename ItemType>
bool BinarySearchTree<KeyType,ItemType>::contains(const KeyType& anEntry)const{
  if(findNode(rootPtr,anEntry) ==nullptr){
    return false;
  }else{
    return true;
  }
}
template<typename KeyType,typename ItemType>
BinarySearchTree<KeyType,ItemType>& BinarySearchTree<KeyType,ItemType>::operator=(const BinarySearchTree<KeyType,ItemType>& rightHandSide){
  if(this == &rightHandSide){
    return *this;
  }else{
    BinaryNode<ItemType>* newRoot = rightHandSide.rootPtr;
      if(newRoot ==nullptr){
        this->rootPtr = nullptr;
      }else{
        this->rootPtr = BinaryNodeTree<ItemType>::copyTree(newRoot);
      }
      return *this;
  }
}
