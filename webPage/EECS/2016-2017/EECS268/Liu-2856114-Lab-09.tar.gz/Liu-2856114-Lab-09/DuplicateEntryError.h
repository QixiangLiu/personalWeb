#ifndef DUPLICATEENTRYERROR_H
#define DUPLICATEENTRYERROR_H

#include <stdexcept>
#include <string>

using namespace std;

class DuplicateEntryError : public logic_error
{
public:
   DuplicateEntryError(const string& message = ""):logic_error(message){}
}; // end PrecondViolatedExcep
#endif
