#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>     /* atof */
#include "VideoGame.h"
#include "BinarySearchTree.h"
#include "DuplicateEntryError.h"
#include "NotFoundException.h"
#include "PrecondViolatedExcep.h"
#include "TreeTest.h"
#include <limits>
using namespace std;
class Executive{
public:
  Executive();
  Executive(string name);
  ~Executive();
  void run();
  static void print(VideoGame& vg){cout << vg<<endl;}
  static void print(string& str){cout << str<<endl;}

private:
  BinarySearchTree<string,VideoGame>* BST;
  string filename;
  string mark;
  int r;
  string n;
  string n2;
  string pl;
  int y;
  string g;
  string pu;
  double NA;
  double EU;
  double JP;
  double other;
  double global;
  void menu();
  void menu2();
  int choice;
};
#endif
