//Video game.h
#ifndef VIDEOGAME_H
#define VIDEOGAME_H
#include <iostream>
#include <istream>
#include <ostream>
#include <string>
using namespace std;
class VideoGame{
public:
  VideoGame();
  VideoGame(int R,string N,string PF,int Y,string G,string P,double NA,
    double EU,double JP,double other,double global);
  VideoGame(string N,string PF,double other);
  ~VideoGame();
  string getName()const;
  void setName(string N);
  int getRank()const;
  string getPlatform()const;
  int getYear()const;
  string getGenre()const;
  string getPublisher()const;
  double getNA()const;
  double getEU()const;
  double getJP()const;
  double getOther()const;
  double getGlobal()const;
  bool operator>(const VideoGame& vg)const;
  bool operator==(const VideoGame& vg)const;
  bool operator==(const string& Videoname)const;
  bool operator>(const string& Videoname)const;


private:
  int rank;
  string name;
  string platform;
  int year;
  string genre;
  string publisher;
  double NA_sales;
  double EU_sales;
  double JP_sales;
  double other_sales;
  double global_sales;
};
#endif
//Global stream operators
//std::istream& operator>>(std::istream& is, VideoGame& vg);
std::ostream& operator<<(std::ostream& os, const VideoGame& vg);
