#ifndef LIST_H
#define LIST_H
#include "Node.h"
#include "ListInterface.h"
#include "PrecondViolatedExcep.h"
template <class T>
class List:public ListInterface<T>{
private:
	Node<T>* headPtr;
	int itemCount;
	Node<T>* getNodeAt(int position)const;
	//void copyListNode(const List<T>& aList);
public:
	List();
	List(const List<T>& aList); //copy constructor
	List<T>& operator=(const List<T>& aList); //override =
	~List();
	bool isEmpty()const;
	int getLength()const;
	void insert(int newPosition,const T& newEntry) throw(PrecondViolatedExcep);
	void remove(int pos) throw(PrecondViolatedExcep);
	void clear();
	T getEntry(int position)const throw(PrecondViolatedExcep);
	void setEntry(int pos, const T& newEntry) throw(PrecondViolatedExcep);
	//T getEntry(const T& itemName) throw (PrecondViolatedExcep);


};
#include "List.cpp"
#endif
