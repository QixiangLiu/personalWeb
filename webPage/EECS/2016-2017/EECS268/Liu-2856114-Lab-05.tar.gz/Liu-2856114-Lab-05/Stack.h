#ifndef STACK_H
#define STACK_H
#include "PrecondViolatedExcep.h"
#include "Node.h"
#include "StackInterface.h"
template <class T>
class Stack:public StackInterface<T>{
private:
  Node<T>* topPtr;
public:
  Stack();
  ~Stack();
 Stack(const Stack<T>& aStack);
 Stack<T>& operator=(const Stack<T>& aStack);
 bool isEmpty()const;
 void push(const T& newEntry) throw(PrecondViolatedExcep);
 void pop() throw(PrecondViolatedExcep);
 T peek()const throw(PrecondViolatedExcep);


};
#include "Stack.cpp"
#endif
