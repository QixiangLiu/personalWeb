/*
file name: main.cpp
Name:Qixiang Liu
KUID:2856114
Date: 10/02/17
Homework: EECS268_lab5
Desciption: use list or queue or stack to simulate to play a card.
*/


#include <iostream>
#include "Executive.h"
using namespace std;
int main(int argc, char* argv[]){
  if(argc<2){
    cout << "Wrong number\n";
  }else{
    Executive myExe(argv[1]);
    myExe.run();
  }

return 0;
}
