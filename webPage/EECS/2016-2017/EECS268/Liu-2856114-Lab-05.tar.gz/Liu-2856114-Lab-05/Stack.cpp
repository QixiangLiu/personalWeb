template<class T>
Stack<T>::Stack():topPtr(nullptr){}

template<class T>
Stack<T>::~Stack(){
  while(!isEmpty())
  pop();
}

template<class T>
bool Stack<T>::isEmpty()const{return topPtr==nullptr;}

template<class T>
void Stack<T>::push(const T& newEntry) throw(PrecondViolatedExcep){
  Node<T>* newNode = new Node<T>(newEntry,topPtr);
  topPtr = newNode;
}

template <class T>
T Stack<T>::peek()const throw(PrecondViolatedExcep){
  if(isEmpty()){
    throw PrecondViolatedExcep("No item to peek!\n");
  }else{
    return topPtr->getItem();
  }
}

template <class T>
void Stack<T>::pop() throw(PrecondViolatedExcep){
  if(isEmpty()){
    throw PrecondViolatedExcep("No input to pop!\n");
  }else{
    Node<T>* deNode =topPtr;
    topPtr=topPtr->getNext();
    deNode->setNext(nullptr);
    delete deNode;
    deNode = nullptr;
  }
}
template<class T>
Stack<T>::Stack(const Stack<T>& aStack)
{
	// Point to nodes in original chain
	Node<T>* origChainPtr = aStack.topPtr;

	if (origChainPtr == nullptr)
		topPtr = nullptr;  // Original stack is empty
	else
	{
		// Copy first node
		topPtr = new Node<T>;
		topPtr->setItem(origChainPtr->getItem());
		// Initialize last node in new chain
		Node<T>* newChainPtr = topPtr;
		// Advance original-chain pointer past first node
		origChainPtr = origChainPtr->getNext();
		// Copy remaining nodes
		while (origChainPtr != nullptr)
		{
			// Get next item from original chain
			T nextItem = origChainPtr->getItem();
			// Advance original-chain pointer
			origChainPtr = origChainPtr->getNext();
			// Create a new node containing the next item
			Node<T>* newNodePtr = new Node<T>(nextItem);
			// Link new node to end of new chain
			newChainPtr->setNext(newNodePtr);
			// Advance pointer to new last node
			newChainPtr = newChainPtr->getNext();
		}  // end while

		newChainPtr->setNext(nullptr);           // Flag end of chain
	}  // end if
}  // end copy constructor

template<class T>
Stack<T>& Stack<T>::operator=(const Stack<T>& aStack)
{
  if(this==&aStack){
    return *this;
  }else{
	// Point to nodes in original chain
	Node<T>* origChainPtr = aStack.topPtr;

	if (origChainPtr == nullptr)
		topPtr = nullptr;  // Original stack is empty
	else
	{
		// Copy first node
		topPtr = new Node<T>;
		topPtr->setItem(origChainPtr->getItem());

		// Initialize last node in new chain
		Node<T>* newChainPtr = topPtr;

		// Advance original-chain pointer past first node
		origChainPtr = origChainPtr->getNext();

		// Copy remaining nodes
		while (origChainPtr != nullptr)
		{
			// Get next item from original chain
			T nextItem = origChainPtr->getItem();

			// Advance original-chain pointer
			origChainPtr = origChainPtr->getNext();

			// Create a new node containing the next item
			Node<T>* newNodePtr = new Node<T>(nextItem);

			// Link new node to end of new chain
			newChainPtr->setNext(newNodePtr);

			// Advance pointer to new last node
			newChainPtr = newChainPtr->getNext();
		}  // end while

		newChainPtr->setNext(nullptr);           // Flag end of chain
	}  // end if
  return *this;
}
}  // end copy constructor
