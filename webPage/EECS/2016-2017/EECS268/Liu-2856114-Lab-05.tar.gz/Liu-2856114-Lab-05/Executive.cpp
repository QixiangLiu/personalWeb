#include "Executive.h"

Executive::Executive(string file){
	inFile.open(file);
	while(!inFile.good()){
		cout << "file name is not good, please again: \n";
		cin >> file;
		inFile.open(file);
	}
}

void Executive::run(){
wait = new Queue<string>;
table = new List<Player*>;
record =nullptr;
Player* p = nullptr;
int card[52];
IniCard(card,52);
while(true){
	inFile >>command;
	if(inFile.eof()==true){
		break;
	}
	if(command == "WAIT"){
		inFile >> waitName;
		wait->enqueue(waitName);
	}else if(command =="SEATING"){
		for(int i=0;i<4;i++){
			p = new Player(wait->peekFront());
			if(table->getLength()<4){
				table->insert(table->getLength()+1,p); //first in first serve
				wait->dequeue();
			}else{
				cout << "It has 4 people in the table. \n";
				break;
			}
 		}
	}else if(command =="DEAL"){
		srand(time(NULL));
		random_shuffle(&card[0],&card[52]);
		if(table->getLength() <4){
			cout << "Error: no 4 people.\n";
		}else{
			for(int i=0;i<4;i++){
				table->getEntry(i+1)->setCard(card[i]);
			}
		}

	}else if(command=="SHOWDOWN"){
		showDown();
	}else if(command =="STATUS"){
		inFile >> status;
		if(status =="TABLE"){
			for(int i=1;i<=table->getLength();i++){
				cout << table->getEntry(i)->getName()<<" ";
				if(table->getEntry(i)->getCard()!=0){
					if(table->getEntry(i)->getCard()==11){
						cout << "J\n";
					}else if(table->getEntry(i)->getCard()==12){
						cout << "Q \n";
					}else if(table->getEntry(i)->getCard()==13){
						cout << "K \n";
					}else{
						cout << table->getEntry(i)->getCard()<<endl;
					}

				}else{
					cout << "he or she has no card!\n";
				}
			}
		}else if(status=="WAIT_LIST"){
			record =  new Queue<string>;
			while(!(wait->isEmpty())){
				cout << wait->peekFront()<<endl;
				record->enqueue(wait->peekFront());
				wait->dequeue();
			}
			while(!(record->isEmpty())){
				wait->enqueue(record->peekFront());
				record->dequeue();
			}
			delete record;
			record = nullptr;
		}else{
			cout << "No correct status.\n";
		}
	}else if(command =="CLOSE"){
		//cout <<"check table: ";
		for(int i=1;i<=table->getLength();i++){
			delete table->getEntry(i);
		}
		delete table;
		table=nullptr;
		//cout << "Check wait list: ";
		delete wait;
		wait = nullptr;
		cout << "Close the game\n";
		break;
	}else{
		cout <<"No correct command!\n";
	}
}
inFile.close();
}

void Executive::showDown(){
	int arr[4];
	int count =3;
	int smallest=1;
	if(table->getLength() <4){
		cout << "Error: no 4 people.\n";
	}else{
		for(int i=0;i<4;i++){
			arr[i] = table->getEntry(i+1)->getCard();
		}
		while(count!=0){
			for(int i=0;i<count;i++){
				if(arr[i]>arr[i+1]){
					int temp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = temp;
				}//endif
			}//endfor
			count--;
		}
		for(int i=0;i<4;i++){
			if(arr[i]!=1){
				smallest = arr[i];
				break;
			}
		}
		if(arr[0]==arr[1]&&arr[0]==arr[2]&&arr[0]==arr[3]){
			cout << "4 poeple have the same hand.\n";
		}else{
			int count =4;
			for(int i=1;i<=count;i++){
				if(smallest == table->getEntry(i)->getCard()){
					delete table->getEntry(i);
					table->remove(i);
					i--;
					count--;
				}
			}
		}
		//return card to dealer
		for(int i=1;i<=table->getLength();i++){
			table->getEntry(i)->setCard(0);
		}
	}

}

void Executive::IniCard(int arr[],int size){
	for(int i=0;i<52;i++){
		arr[i] =i+1;
	}
	for(int i=0;i<size;i++){
	  if(arr[i]%13==0){
	    arr[i] =13;
	  }else if(arr[i]%13==1){
	    arr[i] =1;
	  }else if(arr[i]%13==2){
	    arr[i] =2;
	  }else if(arr[i]%13==3){
	    arr[i] =3;
	  }else if(arr[i]%13==4){
	    arr[i] =4;
	  }else if(arr[i]%13==5){
	    arr[i] =5;
	  }else if(arr[i]%13==6){
	    arr[i] =6;
	  }else if(arr[i]%13==7){
	    arr[i] =7;
	  }else if(arr[i]%13==8){
	    arr[i] =8;
	  }else if(arr[i]%13==9){
	    arr[i] =9;
	  }else if(arr[i]%13==10){
	    arr[i] =10;
	  }else if(arr[i]%13==11){
	    arr[i] =11;
	  }else if(arr[i]%13==12){
	    arr[i] =12;
	  }
	}
}

/*
void Executive::shuffle(int arr[],int size){
	srand(time(NULL));
	random_shuffle(&arr[0],&arr[size]);
	srand(time(NULL));
	for(int i=0;i<size;i++){
	  int num = rand()%(i+1);
		cout << num<<" ";
	  if(num!=i){
	    int temp = arr[num];
	    arr[num] = arr[i];
	    arr[i] = temp;
	  }
	}


}
*/
