/*
file name: main.cpp
Name:Qixiang Liu
KUID:2856114
Date: 10/02/17
Homework: EECS268_lab5
Desciption: use list or queue or stack to simulate to play a card.
*/

#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include "Queue.h"
#include <fstream>
#include <iostream>
#include "Player.h"
#include <time.h>   //time
#include "List.h"
#include <algorithm> //random_shuffle
#include <cstdlib>  //rand or std::srand
using namespace std;
class Executive{
private:
Queue<string>* wait;
Queue<string>* record;
//string filename;
string waitName;
string command;
ifstream inFile;
List<Player*>* table;
string status;
/*
pre: none
post specific card ot no card
return: show card
*/
void showDown();
public:
Executive(string file);
/*
pre: array siez is right
post: none
return 52 card into the array
*/
void IniCard(int arr[],int size);
void run();
};

#endif
