#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include <string>
class Player{
private:
  std::string name;
  int card;

public:
  Player();//default constructor
  Player(std::string playerName);
  ~Player();  //deconstructor
  //Player(const Player& aPlayer);
  //Player& operator=(const Player& aPlayer);
  int getCard()const;
  std::string getName()const;
  void setCard(int newCard);
  void setName(std::string playerName);


};
#endif
