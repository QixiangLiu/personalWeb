#include "Player.h"

Player::Player():name("Qi"),card(0){}

Player::Player(std::string playerName):name(playerName),card(0){}
/*
Player::Player(const Player& aPlayer){
  name = aPlayer.name;
  card = aPlayer.card;
}
Player& Player::operator=(const Player& aPlayer){
  if(this == &aPlayer){
    return *this;
  }else{
    name = aPlayer.name;
    card = aPlayer.card;
    return *this;
  }
}
*/
Player::~Player(){}

int Player::getCard()const{return card;}

std::string Player::getName() const{return name;}

void Player::setCard(int newCard){card=newCard;}

void Player::setName(std::string playerName){name =playerName;}
