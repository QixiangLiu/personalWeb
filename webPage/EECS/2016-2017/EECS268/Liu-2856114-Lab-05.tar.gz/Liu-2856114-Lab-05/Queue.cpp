//Queue.cp
template <class T>
Queue<T>::Queue():topPtr(nullptr){}
/*
template <class T>
int Queue<T>::getLength()const {return size};
*/
template <class T>
Queue<T>::~Queue(){
while(!isEmpty()){
	dequeue();
}
}
template <class T>
bool Queue<T>::isEmpty()const{return topPtr==nullptr;}
//dequeue
template <class T>
void Queue<T>::dequeue() throw(PrecondViolatedExcep){
if(isEmpty()){
	throw PrecondViolatedExcep("No dequeue()!\n");
}else{
	Node<T>* curr = topPtr;
	topPtr =topPtr->getNext();
	curr->setNext(nullptr);
	delete curr;
	curr =nullptr;
	//size--;
}
}

template <class T>
void Queue<T>::enqueue(const T& newEntry) throw(PrecondViolatedExcep){
	Node<T>* newNode = new Node<T>(newEntry,nullptr);
	if(isEmpty()){
		topPtr = newNode;
	}else{

	Node<T>* curr = topPtr;
	while(curr->getNext()!=nullptr){
	curr = curr->getNext();
	}
	curr->setNext(newNode);
	}
	//size++;
}

template <class T>
T Queue<T>::peekFront()const throw(PrecondViolatedExcep){
if(isEmpty()){
	throw PrecondViolatedExcep("No peekFront()!\n");

}else{
	return topPtr->getItem();
}
}
//copy constructor
template <class T>
Queue<T>::Queue(const Queue<T>& aQueue){
	Node<T>* origChainPtr = aQueue.topPtr;
	if (origChainPtr == nullptr)
		topPtr = nullptr;  // Original stack is empty
	else
	{
		topPtr = new Node<T>;
		topPtr->setItem(origChainPtr->getItem());
		Node<T>* newChainPtr = topPtr;
		origChainPtr = origChainPtr->getNext();
		while (origChainPtr != nullptr)
		{
			T nextItem = origChainPtr->getItem();
			origChainPtr = origChainPtr->getNext();
			Node<T>* newNodePtr = new Node<T>(nextItem);
			newChainPtr->setNext(newNodePtr);
			newChainPtr = newChainPtr->getNext();
		}  // end while

		newChainPtr->setNext(nullptr);           // Flag end of chain
	}  // end if
}
//overload operator =
template <class T>
Queue<T>& Queue<T>::operator=(const Queue<T>& aQueue){
	if(this ==&aQueue){
		return *this;
	}else{
		// Point to nodes in original chain
		Node<T>* origChainPtr = aQueue.topPtr;

		if (origChainPtr == nullptr)
			topPtr = nullptr;  // Original stack is empty
		else
		{
			// Copy first node
			topPtr = new Node<T>;
			topPtr->setItem(origChainPtr->getItem());
			// Initialize last node in new chain
			Node<T>* newChainPtr = topPtr;
			// Advance original-chain pointer past first node
			origChainPtr = origChainPtr->getNext();
			// Copy remaining nodes
			while (origChainPtr != nullptr)
			{
				// Get next item from original chain
				T nextItem = origChainPtr->getItem();
				// Advance original-chain pointer
				origChainPtr = origChainPtr->getNext();
				// Create a new node containing the next item
				Node<T>* newNodePtr = new Node<T>(nextItem);
				// Link new node to end of new chain
				newChainPtr->setNext(newNodePtr);
				// Advance pointer to new last node
				newChainPtr = newChainPtr->getNext();
			}  // end while

			newChainPtr->setNext(nullptr);   
		}  // end if
		return *this;
	}
}
