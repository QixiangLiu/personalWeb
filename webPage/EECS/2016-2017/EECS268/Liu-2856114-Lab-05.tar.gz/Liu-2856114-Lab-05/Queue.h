#ifndef QUEUE_H
#define QUEUE_H
#include "QueueInterface.h"
#include "PrecondViolatedExcep.h"
#include "Node.h"


template <class T>
class Queue:public QueueInterface<T>{
private:
Node<T>* topPtr;
//int size;
public:
Queue();
Queue(const Queue<T>& aQueue);
Queue<T>& operator=(const Queue<T>& aQueue);
~Queue();
bool isEmpty()const;
void enqueue(const T& newEntry) throw(PrecondViolatedExcep);
void dequeue() throw(PrecondViolatedExcep);
T peekFront()const throw(PrecondViolatedExcep);
};
#include "Queue.cpp"
#endif
