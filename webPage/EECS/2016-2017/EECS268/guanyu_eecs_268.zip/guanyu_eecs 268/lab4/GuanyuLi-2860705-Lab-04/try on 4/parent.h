#ifndef PARENT_H
#define PARENT_H
#include<iostream>
using namespace std;

class parent
{
private:
public:
  bool isBalenced(char* sample, int count, int count2, int count3);
};
#endif
