var searchData=
[
  ['job',['job',['../structKillCommand.html#abd4689c605a3dfe202a1779f0d1191ae',1,'KillCommand']]],
  ['job_5fstr',['job_str',['../structKillCommand.html#a174a9714a69550b0bbf611e59bfbf332',1,'KillCommand']]],
  ['jobs',['jobs',['../unionCommand.html#abeb4905f11baf90a800fe211dd5ecdc9',1,'Command']]],
  ['jobscommand',['JobsCommand',['../command_8h.html#a027de4ed5fe4b0313c6c8ee0c2c1806b',1,'command.h']]]
];
