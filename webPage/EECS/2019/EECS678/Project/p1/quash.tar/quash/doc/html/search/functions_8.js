var searchData=
[
  ['new_5fdestructable_5fexample',['new_destructable_Example',['../deque_8h.html#a4a210705b6f22fe97b7033bb8854a4d6',1,'deque.h']]],
  ['new_5fexample',['new_Example',['../deque_8h.html#ae0c6f52c89e2b087e19e3062186144da',1,'deque.h']]]
];
