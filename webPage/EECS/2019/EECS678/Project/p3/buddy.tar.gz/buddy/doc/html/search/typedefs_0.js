var searchData=
[
  ['severity_5ft',['severity_t',['../simulator_8c.html#ad5a621860cea3000d6fff61b24c953bc',1,'simulator.c']]],
  ['status_5ft',['status_t',['../simulator_8c.html#a64ad11e0cd0712cd5ab6b65bafb01eaf',1,'simulator.c']]]
];
