var searchData=
[
  ['page_5fsize',['PAGE_SIZE',['../buddy_8c.html#a7d467c1d283fdfa1f2081ba1e0d01b6e',1,'buddy.c']]],
  ['page_5ft',['page_t',['../structpage__t.html',1,'']]],
  ['page_5fto_5faddr',['PAGE_TO_ADDR',['../buddy_8c.html#a7c13b46aacf7af9976a7f058076c81a3',1,'buddy.c']]],
  ['parse_5falloc',['parse_alloc',['../simulator_8c.html#ab2e9ac714e741c607dbef0bfeff8b148',1,'simulator.c']]],
  ['parse_5fcommand',['parse_command',['../simulator_8c.html#a71b9b835156c5f3ff75bb95cb7c427c8',1,'simulator.c']]],
  ['parse_5ferror',['parse_error',['../simulator_8c.html#a1adfffecd0993f3a4bb6426897772e2c',1,'simulator.c']]],
  ['parse_5ffile',['parse_file',['../simulator_8c.html#a160f92b4b98f55d67f6d5a43d8eaca47',1,'simulator.c']]],
  ['parse_5ffree',['parse_free',['../simulator_8c.html#a80e5827b1591103e4ac9fb18d481d5ca',1,'simulator.c']]],
  ['pdebug',['PDEBUG',['../buddy_8c.html#a9077500d1488a75e4eec5eeb1131655e',1,'buddy.c']]],
  ['prev',['prev',['../structlist__head.html#aaa0eabda8877e1d6de73a33f223ad004',1,'list_head']]],
  ['print_5ffault',['print_fault',['../simulator_8c.html#aaa8f28ba555442b97037658d80c1a183',1,'simulator.c']]],
  ['print_5fusage',['print_usage',['../simulator_8c.html#a1af618f96cd775693d6a82cafc0e6057',1,'simulator.c']]]
];
