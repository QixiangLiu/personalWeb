var searchData=
[
  ['var_5fmap',['var_map',['../simulator_8c.html#aac0a9bd81116672e0737054410aa7dc0',1,'simulator.c']]],
  ['var_5ft',['var_t',['../structvar__t.html',1,'var_t'],['../simulator_8c.html#ab704ad908455614a28b1de273bfa897d',1,'var_t():&#160;simulator.c']]]
];
