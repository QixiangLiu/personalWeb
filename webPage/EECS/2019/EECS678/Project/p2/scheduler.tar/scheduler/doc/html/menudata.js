var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"p",url:"globals.html#index_p"},
{text:"s",url:"globals.html#index_s"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"p",url:"globals_func.html#index_p"},
{text:"s",url:"globals_func.html#index_s"}]},
{text:"Enumerations",url:"globals_enum.html"}]}]}]}
