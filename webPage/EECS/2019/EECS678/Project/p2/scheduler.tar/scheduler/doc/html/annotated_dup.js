var annotated_dup =
[
    [ "job_t", "structjob__t.html", null ],
    [ "priqueue_t", "structpriqueue__t.html", null ]
];