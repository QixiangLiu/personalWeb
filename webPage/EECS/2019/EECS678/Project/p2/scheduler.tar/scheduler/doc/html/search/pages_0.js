var searchData=
[
  ['compare_20function',['Compare Function',['../comparer-page.html',1,'']]]
];
