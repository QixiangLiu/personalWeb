// Cylinder.h

#ifndef CYLINDER_H
#define CYLINDER_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "SceneElement.h"

class Cylinder : public SceneElement
{
public:
	Cylinder(ShaderIF* sIF,PhongMaterial& matlIn,double xleft,double xright,double y,double z,double radius);
	virtual ~Cylinder();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimits) const;
	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
	void render();
	void renderCylinder();
private:
	//ShaderIF* shaderIF;
	PhongMaterial matl;

	GLuint vao[1];
	GLuint vbo[2]; // 0: coordinates; 1: normal vectors
	//float kd[3];
	double xmin, xmax, ymin, ymax, zmin, zmax;
	double x1,x2,yb,zb;
	void defineCylinder(double x1, double x2, double yb, double zb, double r);
};

#endif
