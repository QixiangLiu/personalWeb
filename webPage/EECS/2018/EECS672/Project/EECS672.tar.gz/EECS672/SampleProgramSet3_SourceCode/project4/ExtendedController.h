// ExtendedController.h

#ifndef EXTENDEDCONTROLLER_H
#define EXTENDEDCONTROLLER_H

#include "GLFWController.h"
#include "SceneElement.h"

class ExtendedController : public GLFWController
{
private:
	int lastMouseX;
	int lastMouseY;
	bool LeftMousePressed;
	bool drawingOpaqueObjects;
protected:
	void handleMouseMotion(int x, int y);
	void handleDisplay();
public:
	ExtendedController(const std::string& name, int rcFlags = 0);
	bool drawingOpaque()const; // CALLED FROM SceneElement or descendant classes

};

#endif
