// Cylinder.h

#ifndef CYLINDER2_H
#define CYLINDER2_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "ModelView.h"
#include "ShaderIF.h"
#include "SceneElement.h"

class Cylinder2 : public SceneElement
{
public:
	Cylinder2(ShaderIF* sIF,PhongMaterial& matlIn,double x,double ytop,double ybottom,double z,double radius);
	virtual ~Cylinder2();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimits) const;
	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
	void render();
	void renderCylinder();
private:
	//ShaderIF* shaderIF;
	GLuint vao[1];
	GLuint vbo[2]; // 0: coordinates; 1: normal vectors
//	float kd[3];
	double xmin, xmax, ymin, ymax, zmin, zmax;
	PhongMaterial matl;

	void defineCylinder(double y1, double y2, double zb, double xb, double r);
};

#endif
