var searchData=
[
  ['setalwaysgeneratepervertexnormals',['setAlwaysGeneratePerVertexNormals',['../classBasicShape.html#a4ab2e4c0a4006856595b9c98859ded3a',1,'BasicShape']]],
  ['setglslvariablenames',['setGLSLVariableNames',['../classBasicShapeRenderer.html#a0536cb4e327de329b0e35f6767a7dc1a',1,'BasicShapeRenderer']]],
  ['settexcoordsforblock',['setTexCoordsForBlock',['../classBasicShapeRenderer.html#a40539fb591ef5b67b457917e0194b6cd',1,'BasicShapeRenderer']]],
  ['setuseebos',['setUseEBOs',['../classBasicShapeRenderer.html#ad32714ef6a769eb97ce33c7307471c70',1,'BasicShapeRenderer']]]
];
