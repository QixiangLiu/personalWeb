// Moon.h

#ifndef MOON_H
#define MOON_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "SceneElement.h"
#include "AffPoint.h"
#include "AffVector.h"
#include "BasicShapeRenderer.h"

class Moon : public SceneElement
{
public:
	Moon(ShaderIF* sIF, const PhongMaterial& matlIn,const char* texImageSource,cryph::AffPoint sphere, double radius);
	virtual ~Moon();

	void getMCBoundingBox(double* xyzLimits) const; // {xmin, xmax, ymin, ymax, zmin, zmax}
	void render();
	void renderMoon();
	static void prepareForFace(void* caller, int faceIndex);
protected:

private:
	bool isUseTexture;
	BasicShape* pieces[1];
	BasicShapeRenderer* piecesR[1];
	PhongMaterial matl;

	double xyz[6];

	void defineInitialGeometry(cryph::AffPoint sphere,double radius);
};

#endif
