// Block.h

#ifndef BEZIERCURVE_H
#define BEZIERCURVE_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "SceneElement.h"

class BezierCurve : public SceneElement
{
public:
  BezierCurve(const cryph::AffPoint* cPts, int degreeIn);
  ~BezierCurve();

  void defineInitialGeometry(const cryph::AffPoint* cPts);
  void renderBezierCurve();
  void render();
  void getMCBoundingBox(double* xyzLimits) const;

protected:

private:
  GLuint vao[1];
	GLuint vbo[1];
  int degree;
  float pointSize;
  float maxPixelLength;
  float xmin, xmax, ymin, ymax, zmin, zmax;

};

#endif
