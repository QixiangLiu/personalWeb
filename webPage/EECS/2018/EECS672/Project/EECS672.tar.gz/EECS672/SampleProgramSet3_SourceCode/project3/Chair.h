// Chair.h

#ifndef CHAIR_H
#define CHAIR_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif
#include <string>

#include "SceneElement.h"
#include "AffPoint.h"
#include "AffVector.h"
#include "BasicShapeRenderer.h"
class Chair : public SceneElement
{
public:
	Chair(ShaderIF* sIF, const PhongMaterial& matlIn,
		cryph::AffPoint corner, cryph::AffVector u,
		double legHeight, double legRadius,
		double ChairWidth, double ChairDepth, double ChairThickness);
	virtual ~Chair();

	void getMCBoundingBox(double* xyzLimits) const; // {xmin, xmax, ymin, ymax, zmin, zmax}
	void render();
	void renderChair();

private:
	BasicShape* pieces[8]; // top and four legs
	BasicShapeRenderer* piecesR[8];
	int currentlyDrawingPiece; // used only in context of "prepareForFace"
	GLuint texID;
	PhongMaterial matl;

	double xyz[6];

	void defineInitialGeometry(cryph::AffPoint corner, cryph::AffVector u,
		double legHeight, double legRadius,
		double ChairWidth, double ChairDepth, double ChairThickness);

	static void prepareForFace(void* caller, int faceIndex);
};

#endif
