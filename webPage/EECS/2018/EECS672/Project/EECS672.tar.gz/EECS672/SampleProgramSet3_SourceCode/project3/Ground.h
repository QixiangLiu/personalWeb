// Ground.h

#ifndef GROUND_H
#define GROUND_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "SceneElement.h"

class Ground : public SceneElement
{
public:
	Ground(ShaderIF* sIF, const PhongMaterial& matlIn,
		double xmin, double xmax, double zmin, double zmax);
	virtual ~Ground();

	void getMCBoundingBox(double* xyzLimits) const; // {xmin, xmax, ymin, ymax, zmin, zmax}
	void render();
	void renderGround();

private:
	GLuint vao;
	GLuint buffer; // coordinates
	PhongMaterial matl;

	double xyz[6];
	double nx, ny, nz;

	void defineInitialGeometry();
};

#endif
