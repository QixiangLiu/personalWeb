// Cylinder.h

#ifndef CONE_H
#define CONE_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "ModelView.h"
#include "SceneElement.h"
class Cone : public SceneElement
{
public:
	Cone(ShaderIF* sIF,PhongMaterial& matlIn,const char* texImageSource,
		double x,double ytop,double ybottom,double z,double radius,int m=0);
	virtual ~Cone();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimits) const;
	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
	void render();
	void renderCone();
protected:
	GLuint texID;
	GLenum wrapS, wrapT;
private:
	int mode;
	bool isUseTexture;
	//ShaderIF* shaderIF;
	GLuint vao[1];
	GLuint vbo[3]; // 0: coordinates; 1: normal vectors
	// float kd[3];
	double xmin, xmax, ymin, ymax, zmin, zmax;

	PhongMaterial matl;

	void defineCone(double y1, double y2, double xb, double zb, double r);
};

#endif
