// Lamp.h

#ifndef Lamp_H
#define Lamp_H

#include "SceneElement.h"
#include "AffPoint.h"
#include "AffVector.h"
#include "BasicShapeRenderer.h"

class Lamp : public SceneElement
{
public:
	Lamp(ShaderIF* sIF,PhongMaterial& matlIn,cryph::AffPoint corner,double legHeight, double lampRadius);
	virtual ~Lamp();

	void getMCBoundingBox(double* xyzLimits) const; // {xmin, xmax, ymin, ymax, zmin, zmax}
	void render();
	void renderLamp();

private:
	BasicShape* pieces[3]; // top and four legs
	BasicShapeRenderer* piecesR[3];
	int currentlyDrawingPiece; // used only in context of "prepareForFace"
	GLuint texID;
	PhongMaterial matl;

	double xyz[6];

	void defineInitialGeometry(cryph::AffPoint corner,double legHeight, double lampRadius);

	static void prepareForFace(void* caller, int faceIndex);
};
#endif
