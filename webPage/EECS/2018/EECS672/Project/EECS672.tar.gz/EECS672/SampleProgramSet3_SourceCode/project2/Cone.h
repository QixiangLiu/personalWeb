// Cylinder.h

#ifndef CONE_H
#define CONE_H

#ifdef __APPLE_CC__
#include "GLFW/glfw3.h"
#else
#include <GL/gl.h>
#endif

#include "ModelView.h"
#include "ShaderIF.h"

class Cone : public ModelView
{
public:
	Cone(ShaderIF* sIF,double x,double ytop,double ybottom,double z,double radius,float color[3]);
	virtual ~Cone();

	// xyzLimits: {mcXmin, mcXmax, mcYmin, mcYmax, mcZmin, mcZmax}
	void getMCBoundingBox(double* xyzLimits) const;
	bool handleCommand(unsigned char anASCIIChar, double ldsX, double ldsY);
	void render();
	void renderCylinder();
private:
	ShaderIF* shaderIF;
	GLuint vao[1];
	GLuint vbo[2]; // 0: coordinates; 1: normal vectors
	float kd[3];
	double xmin, xmax, ymin, ymax, zmin, zmax;

	void defineCylinder(double y1, double y2, double xb, double zb, double r);
};

#endif
