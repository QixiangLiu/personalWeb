// ExtendedController.h

#ifndef EXTENDEDCONTROLLER_H
#define EXTENDEDCONTROLLER_H

#include "GLFWController.h"
#include "SceneElement.h"

class ExtendedController : public GLFWController
{
private:
	int lastMouseX;
	int lastMouseY;
	bool LeftMousePressed;
protected:
	void handleMouseMotion(int x, int y);
public:
	ExtendedController(const std::string& name, int rcFlags = 0);
};

#endif
